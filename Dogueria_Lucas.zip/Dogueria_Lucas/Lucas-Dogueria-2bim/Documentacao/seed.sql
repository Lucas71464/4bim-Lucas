-- Seed para Dogueria - Dados Iniciais

-- Inserir usuário gerente (senha: admin123)
-- Hash gerado com bcrypt, 10 rounds
INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo, criado_em) 
VALUES (
  'Administrador', 
  'admin@dogueria.com', 
  '$2b$10$rZ5qhHqKqX5YJZ5YJZ5YJuO5YJZ5YJZ5YJZ5YJZ5YJZ5YJZ5YJZ5Y',
  'gerente', 
  true, 
  now()
) ON CONFLICT (email) DO NOTHING;

-- Inserir usuário cliente de teste (senha: cliente123)
INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo, criado_em) 
VALUES (
  'Cliente Teste', 
  'cliente@dogueria.com', 
  '$2b$10$aZ5qhHqKqX5YJZ5YJZ5YJuO5YJZ5YJZ5YJZ5YJZ5YJZ5YJZ5YJZ5Y',
  'cliente', 
  true, 
  now()
) ON CONFLICT (email) DO NOTHING;

-- Inserir produtos iniciais
INSERT INTO produtos (nome, descricao, ingredientes, preco, imagem_url, ativo, criado_em) VALUES
('Hot Dog Tradicional', 'Cachorro-quente clássico com salsicha, molho, batata palha e queijo', 'Pão, salsicha, molho de tomate, mostarda, maionese, batata palha, queijo ralado', 8.50, 'https://via.placeholder.com/300x200?text=Hot+Dog+Tradicional', true, now()),
('Hot Dog Especial', 'Hot dog completo com bacon, milho, ervilha e catupiry', 'Pão, salsicha, bacon, milho, ervilha, catupiry, batata palha, molhos', 12.00, 'https://via.placeholder.com/300x200?text=Hot+Dog+Especial', true, now()),
('Hot Dog Vegetariano', 'Versão vegetariana com salsicha de soja e legumes', 'Pão integral, salsicha de soja, cenoura, milho, ervilha, molhos vegetarianos', 10.50, 'https://via.placeholder.com/300x200?text=Hot+Dog+Vegetariano', true, now()),
('Hot Dog Gourmet', 'Hot dog premium com linguiça artesanal e queijos especiais', 'Pão brioche, linguiça artesanal, queijo brie, rúcula, tomate seco, molho especial', 15.00, 'https://via.placeholder.com/300x200?text=Hot+Dog+Gourmet', true, now()),
('Refrigerante Lata', 'Refrigerante gelado 350ml', 'Refrigerante 350ml', 4.50, 'https://via.placeholder.com/300x200?text=Refrigerante', true, now()),
('Suco Natural', 'Suco natural de frutas 500ml', 'Frutas frescas, água, açúcar opcional', 6.00, 'https://via.placeholder.com/300x200?text=Suco+Natural', true, now()),
('Batata Frita', 'Porção de batata frita crocante', 'Batata, óleo, sal', 8.00, 'https://via.placeholder.com/300x200?text=Batata+Frita', true, now()),
('Combo Família', '4 Hot Dogs Tradicionais + 4 Refrigerantes + Batata Frita Grande', 'Hot dogs, refrigerantes, batata frita', 55.00, 'https://via.placeholder.com/300x200?text=Combo+Familia', true, now())
ON CONFLICT DO NOTHING;
