const express = require('express');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const app = express();
const path = require('path');
const cookieParser = require('cookie-parser');
require('dotenv').config();

// Importar a configuração do banco PostgreSQL
const db = require('./database');

// Configurações do servidor
const HOST = 'localhost';
const PORT_FIXA = 3000;

// Servir a pasta frontend como arquivos estáticos
const caminhoFrontend = path.join(__dirname, '../frontend');
console.log('📁 Caminho frontend:', caminhoFrontend);

app.use(express.static(caminhoFrontend));
app.use(cookieParser());
app.use(express.json());

// Configurar sessão com PostgreSQL
app.use(session({
  store: new pgSession({
    pool: db.pool,
    tableName: 'session',
    createTableIfMissing: false
  }),
  secret: process.env.SESSION_SECRET || 'dogueria-winchester-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000, // 24 horas
    httpOnly: false, // Permite acesso via JavaScript para compatibilidade
    secure: false, // true apenas em HTTPS
    sameSite: 'lax'
  }
}));

// Middleware CORS
app.use((req, res, next) => {
  const allowedOrigins = [
    'http://127.0.0.1:5500',
    'http://localhost:5500', 
    'http://127.0.0.1:5501', 
    'http://localhost:3000', 
    'http://localhost:3001'
  ];
  
  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }
  
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  res.header('Access-Control-Allow-Credentials', 'true');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

// Middleware para adicionar a instância do banco de dados às requisições
app.use((req, res, next) => {
  req.db = db;
  next();
});

// Middleware de tratamento de erros JSON malformado
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      error: 'JSON malformado',
      message: 'Verifique a sintaxe do JSON enviado'
    });
  }
  next(err);
});

// ================================================================
// IMPORTAR E REGISTRAR ROTAS
// ================================================================

// Rotas de autenticação (novas rotas padronizadas em /api/*)
const authController = require('./controllers/loginController');

// Rotas públicas de autenticação
app.post('/api/login', authController.verificarSenha);
app.post('/api/register', authController.criarUsuario);
app.post('/api/logout', authController.logout);
app.get('/api/me', (req, res) => {
  if (req.session && req.session.usuario) {
    return res.json({ 
      status: 'ok', 
      usuario: {
        id: req.session.usuario.id,
        nome: req.session.usuario.nome,
        email: req.session.usuario.email,
        cargo: req.session.usuario.cargo,
        avatar_url: req.session.usuario.avatar_url
      }
    });
  }
  return res.status(401).json({ status: 'nao_logado', message: 'Usuário não está logado' });
});

// Rotas antigas (manter para compatibilidade)
const loginRoutes = require('./routes/loginRoutes');
app.use('/login', loginRoutes);

// Rotas de recursos
const clienteRoutes = require('./routes/clienteRoutes');
app.use('/api/clientes', clienteRoutes);

const produtoRoutes = require('./routes/produtoRoutes');
app.use('/api/produtos', produtoRoutes);

const pedidoRoutes = require('./routes/pedidoRoutes');
app.use('/api/pedidos', pedidoRoutes);

const itemPedidoRoutes = require('./routes/itemPedidoRoutes');
app.use('/api/itens-pedido', itemPedidoRoutes);

const usuarioRoutes = require('./routes/usuarioRoutes');
app.use('/api/usuarios', usuarioRoutes);

const perfilRoutes = require('./routes/perfilRoutes');
app.use('/api/perfis', perfilRoutes);

const configRoutes = require('./routes/configRoutes');
app.use('/api/config', configRoutes);

const configGerenteRoutes = require('./routes/configGerenteRoutes');
app.use('/api/config-gerente', configGerenteRoutes);

const relatorioRoutes = require('./routes/relatorioRoutes');
app.use('/api/relatorios', relatorioRoutes);

// ================================================================

// Rota padrão
app.get('/', (req, res) => {
  res.json({
    message: 'O server está funcionando - essa é a rota raiz!',
    database: 'PostgreSQL',
    timestamp: new Date().toISOString()
  });
});

// Rota para testar a conexão com o banco
app.get('/health', async (req, res) => {
  try {
    const connectionTest = await db.testConnection();

    if (connectionTest) {
      res.status(200).json({
        status: 'OK',
        message: 'Servidor e banco de dados funcionando',
        database: 'PostgreSQL',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        status: 'ERROR',
        message: 'Problema na conexão com o banco de dados',
        database: 'PostgreSQL',
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('❌ Erro no health check:', error);
    res.status(500).json({
      status: 'ERROR',
      message: 'Erro interno do servidor',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Middleware global de tratamento de erros
app.use((err, req, res, next) => {
  console.error('❌ Erro não tratado:', err);

  res.status(500).json({
    error: 'Erro interno do servidor',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Algo deu errado',
    timestamp: new Date().toISOString()
  });
});

// Middleware para rotas não encontradas (404)
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Rota não encontrada',
    message: `A rota ${req.originalUrl} não existe`,
    timestamp: new Date().toISOString()
  });
});

// ================================================================
// INICIALIZAÇÃO DO SERVIDOR
// ================================================================

const startServer = async () => {
  try {
    // Testar conexão com o banco antes de iniciar o servidor
    console.log('🔍 Testando conexão com PostgreSQL...');
    const connectionTest = await db.testConnection();

    if (!connectionTest) {
      console.error('❌ Falha na conexão com PostgreSQL');
      process.exit(1);
    }

    console.log('✅ PostgreSQL conectado com sucesso');

    const PORT = process.env.PORT || PORT_FIXA;

    app.listen(PORT, () => {
      console.log(`🚀 Servidor rodando em http://${HOST}:${PORT}`);
      console.log(`📊 Health check disponível em http://${HOST}:${PORT}/health`);
      console.log(`🗄️ Banco de dados: PostgreSQL`);
      console.log(`🌍 Ambiente: ${process.env.NODE_ENV || 'development'}`);
    });

  } catch (error) {
    console.error('❌ Erro ao iniciar o servidor:', error);
    process.exit(1);
  }
};

// Tratamento de sinais para encerramento graceful
process.on('SIGINT', async () => {
  console.log('\n🔴 Encerrando servidor...');

  try {
    await db.pool.end();
    console.log('✅ Conexões com PostgreSQL encerradas');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao encerrar conexões:', error);
    process.exit(1);
  }
});

process.on('SIGTERM', async () => {
  console.log('\n🔴 SIGTERM recebido, encerrando servidor...');

  try {
    await db.pool.end();
    console.log('✅ Conexões com PostgreSQL encerradas');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao encerrar conexões:', error);
    process.exit(1);
  }
});

// Iniciar o servidor
startServer();
