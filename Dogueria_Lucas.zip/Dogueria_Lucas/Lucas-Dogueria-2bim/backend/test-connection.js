// Script de teste de conexão com PostgreSQL
const { pool } = require('./database');

async function testConnection() {
  console.log('🔍 Testando conexão com PostgreSQL...\n');
  
  try {
    // Teste de conexão
    const client = await pool.connect();
    console.log('✅ Conexão estabelecida com sucesso!\n');
    
    // Verificar tabelas
    console.log('📋 Verificando tabelas criadas:');
    const tables = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `);
    
    if (tables.rows.length === 0) {
      console.log('⚠️  Nenhuma tabela encontrada. Execute o script database-setup.sql\n');
    } else {
      tables.rows.forEach(row => {
        console.log(`  ✓ ${row.table_name}`);
      });
      console.log('');
    }
    
    // Contar registros
    console.log('📊 Contagem de registros:');
    const counts = await Promise.all([
      client.query('SELECT COUNT(*) FROM usuarios'),
      client.query('SELECT COUNT(*) FROM produtos'),
      client.query('SELECT COUNT(*) FROM clientes'),
      client.query('SELECT COUNT(*) FROM pedidos'),
      client.query('SELECT COUNT(*) FROM itens_pedido'),
      client.query('SELECT COUNT(*) FROM perfis'),
    ]);
    
    console.log(`  Usuários: ${counts[0].rows[0].count}`);
    console.log(`  Produtos: ${counts[1].rows[0].count}`);
    console.log(`  Clientes: ${counts[2].rows[0].count}`);
    console.log(`  Pedidos: ${counts[3].rows[0].count}`);
    console.log(`  Itens de Pedido: ${counts[4].rows[0].count}`);
    console.log(`  Perfis: ${counts[5].rows[0].count}`);
    console.log('');
    
    console.log('✅ Banco de dados configurado corretamente!\n');
    
    client.release();
    await pool.end();
    
  } catch (error) {
    console.error('❌ Erro ao conectar:', error.message);
    console.log('\n💡 Dicas:');
    console.log('  1. Verifique se o PostgreSQL está rodando');
    console.log('  2. Confirme as credenciais no arquivo .env');
    console.log('  3. Certifique-se de que o banco "dogueria_bd" foi criado');
    console.log('  4. Execute: psql -U postgres -d dogueria_bd -f documentacao/database-setup.sql\n');
    process.exit(1);
  }
}

testConnection();

