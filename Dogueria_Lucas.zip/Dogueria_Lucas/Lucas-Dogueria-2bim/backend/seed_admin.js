const db = require('./database.js');
const bcrypt = require('bcrypt');
require('dotenv').config();

// Script para gerar hash de senha e inserir usuário admin
async function seedAdmin() {
  try {
    console.log('🌱 Iniciando seed de admin...');

    // Verificar se admin já existe
    const adminCheck = await db.query("SELECT id FROM usuarios WHERE email = 'admin@dogueria.local'");
    
    if (adminCheck.rows.length > 0) {
      console.log('✅ Admin já existe no banco de dados');
      process.exit(0);
    }

    // Gerar hash de senha para "admin123"
    const saltRounds = parseInt(process.env.SALT_ROUNDS || '10');
    const senhaOriginal = 'admin123';
    const senhaHash = await bcrypt.hash(senhaOriginal, saltRounds);

    console.log('🔐 Hash de senha gerado');

    // Inserir usuário admin
    const result = await db.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo) VALUES ($1, $2, $3, $4, $5) RETURNING id, nome, email, cargo',
      [
        'Administrador Dogueria',
        'admin@dogueria.local',
        senhaHash,
        'gerente',
        true
      ]
    );

    const admin = result.rows[0];
    console.log('✅ Usuário admin criado com sucesso!');
    console.log('📧 Email:', admin.email);
    console.log('🔑 Senha padrão: admin123 (MUDE ISSO EM PRODUÇÃO!)');
    console.log('👔 Cargo:', admin.cargo);

    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao criar admin:', error);
    process.exit(1);
  }
}

seedAdmin();
