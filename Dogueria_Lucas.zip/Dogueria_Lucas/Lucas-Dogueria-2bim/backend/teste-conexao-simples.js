// Teste de conexão simples com PostgreSQL
const { Pool } = require('pg');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'dogueria_bd',
  user: 'postgres',
  password: '123456'
});

async function testar() {
  console.log('Testando conexão...\n');
  
  try {
    const client = await pool.connect();
    console.log('✅ CONEXÃO FUNCIONOU!');
    
    const result = await client.query('SELECT current_database(), current_user');
    console.log('Banco:', result.rows[0].current_database);
    console.log('Usuário:', result.rows[0].current_user);
    
    client.release();
    await pool.end();
    
  } catch (error) {
    console.log('❌ ERRO:', error.message);
    console.log('\nDetalhes completos:');
    console.log(error);
  }
}

testar();

