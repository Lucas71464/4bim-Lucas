/**
 * Script para gerar hash de senha bcrypt
 * Use para criar senhas criptografadas para inserir no banco
 */

const bcrypt = require('bcrypt');

// Função para gerar hash
async function gerarHash(senha) {
  try {
    const hash = await bcrypt.hash(senha, 10);
    console.log('\n=================================');
    console.log('SENHA:', senha);
    console.log('HASH:', hash);
    console.log('=================================\n');
    console.log('SQL para inserir no banco:');
    console.log(`INSERT INTO usuarios (username, password, role) VALUES`);
    console.log(`('seu_usuario', '${hash}', 'gerente');`);
    console.log('\n');
  } catch (error) {
    console.error('Erro ao gerar hash:', error);
  }
}

// Gerar hashes para senhas padrão
async function gerarHashesPadroes() {
  console.log('\n🔐 Gerando hashes para senhas padrão...\n');
  
  await gerarHash('123456');
  await gerarHash('admin');
  await gerarHash('senha123');
  
  console.log('✅ Hashes gerados! Use os valores acima no banco de dados.\n');
}

// Se você quiser gerar hash para uma senha específica, mude aqui:
const senhaCustomizada = process.argv[2];

if (senhaCustomizada) {
  gerarHash(senhaCustomizada);
} else {
  gerarHashesPadroes();
}

