const db = require('../database.js');

(async () => {
  try {
    const res = await db.query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'usuarios' ORDER BY ordinal_position");
    console.log('Columns in table usuarios:');
    console.table(res.rows);
  } catch (err) {
    console.error('Error while inspecting users table:', err);
  } finally {
    // close pool
    await db.pool.end();
  }
})();
