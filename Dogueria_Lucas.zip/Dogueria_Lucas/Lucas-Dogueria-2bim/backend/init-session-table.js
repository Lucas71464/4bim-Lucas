/**
 * Script para inicializar a tabela de sessões no PostgreSQL
 * Deve ser executado uma vez antes de iniciar o servidor
 */

const { pool } = require('./database');

async function initSessionTable() {
  let client;
  try {
    console.log('🔧 Verificando tabela de sessões...');
    
    client = await pool.connect();

    // Criar tabela session se não existir (compatível com connect-pg-simple)
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS "session" (
        "sid" varchar NOT NULL COLLATE "default",
        "sess" json NOT NULL,
        "expire" timestamp(6) NOT NULL,
        PRIMARY KEY ("sid")
      ) WITH (OIDS=FALSE);

      CREATE INDEX IF NOT EXISTS "IDX_session_expire" on "session" ("expire");
    `;

    await client.query(createTableSQL);
    console.log('✅ Tabela de sessões está pronta');

    // Limpar sessões expiradas
    const cleanupSQL = `
      DELETE FROM "session" WHERE "expire" < NOW();
    `;
    
    const result = await client.query(cleanupSQL);
    if (result.rowCount > 0) {
      console.log(`🧹 Limpeza: ${result.rowCount} sessões expiradas removidas`);
    }

    // Verificar se a tabela tem dados
    const countSQL = `SELECT COUNT(*) as total FROM "session";`;
    const countResult = await client.query(countSQL);
    console.log(`📊 Total de sessões no banco: ${countResult.rows[0].total}`);

  } catch (error) {
    console.error('❌ Erro ao inicializar tabela de sessões:', error);
    throw error;
  } finally {
    if (client) {
      client.release();
    }
  }
}

// Executar se for chamado diretamente
if (require.main === module) {
  initSessionTable()
    .then(() => {
      console.log('✅ Inicialização concluída');
      process.exit(0);
    })
    .catch((err) => {
      console.error('❌ Erro:', err);
      process.exit(1);
    });
}

module.exports = initSessionTable;
