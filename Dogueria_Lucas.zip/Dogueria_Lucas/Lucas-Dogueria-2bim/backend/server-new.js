const express = require('express');
const app = express();
const path = require('path');
const cookieParser = require('cookie-parser');
const session = require('express-session');
require('dotenv').config();

// Importar a configuração do banco PostgreSQL
const db = require('./database');

// Configurações do servidor
const HOST = process.env.DB_HOST || 'localhost';
const PORT = process.env.PORT || 3000;

// ================================================================
// MIDDLEWARES DE SESSÃO E COOKIES
// ================================================================

// Middleware de cookies
app.use(cookieParser());

// Middleware de sessão
app.use(session({
  secret: process.env.SESSION_SECRET || 'uma_senha_secreta_dogueria_2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'Lax',
    maxAge: 24 * 60 * 60 * 1000 // 24 horas
  }
}));

// ================================================================
// MIDDLEWARES GLOBAIS
// ================================================================

// Servir arquivos estáticos (frontend)
const caminhoFrontend = path.join(__dirname, '../frontend');
const caminhoPublic = path.join(__dirname, '../public');
console.log('📁 Caminho frontend:', caminhoFrontend);
console.log('📁 Caminho public:', caminhoPublic);

app.use(express.static(caminhoFrontend));
app.use(express.static(caminhoPublic));

// Middleware para permitir CORS
app.use((req, res, next) => {
  const allowedOrigins = [
    'http://127.0.0.1:5500',
    'http://localhost:5500',
    'http://127.0.0.1:5501',
    'http://localhost:5501',
    'http://localhost:3000',
    'http://localhost:3001',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:3001'
  ];

  const origin = req.headers.origin;
  if (allowedOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }

  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Credentials', 'true');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

// Body parser para JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware para adicionar instância do banco às requisições
app.use((req, res, next) => {
  req.db = db;
  next();
});

// Middleware de tratamento de JSON malformado
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      status: 'erro',
      mensagem: 'JSON malformado',
      details: 'Verifique a sintaxe do JSON enviado'
    });
  }
  next(err);
});

// ================================================================
// ROTAS
// ================================================================

// Rotas de autenticação (novas)
const authRoutes = require('./routes/authRoutes-new.js');
app.use('/api', authRoutes);

// Rotas de usuários (novas)
const usuarioRoutes = require('./routes/usuarioRoutes-new.js');
app.use('/api/usuarios', usuarioRoutes);

// Rotas de produtos (novas)
const produtoRoutes = require('./routes/produtoRoutes-new.js');
app.use('/api/produtos', produtoRoutes);

// Rotas de pedidos (novas)
const pedidoRoutes = require('./routes/pedidoRoutes-new.js');
app.use('/api/pedidos', pedidoRoutes);

// Rotas legadas desabilitadas: usar as rotas modernas em /api/*
try {
  // Se desejar manter compatibilidade, descomente a linha abaixo
  // const loginRoutes = require('./routes/loginRoutes');
  // app.use('/login', loginRoutes);
  console.log('ℹ️ Rotas legadas /login não estão sendo montadas - use /api/*');
} catch (e) {
  console.log('⚠️ Erro ao processar rotas legadas (ignorado)');
}

try {
  const clienteRoutes = require('./routes/clienteRoutes');
  app.use('/api/clientes', clienteRoutes);
} catch (e) {
  console.log('⚠️ clienteRoutes não encontrado');
}

try {
  const itemPedidoRoutes = require('./routes/itemPedidoRoutes');
  app.use('/api/itens-pedido', itemPedidoRoutes);
} catch (e) {
  console.log('⚠️ itemPedidoRoutes não encontrado');
}

try {
  const perfilRoutes = require('./routes/perfilRoutes');
  app.use('/api/perfis', perfilRoutes);
} catch (e) {
  console.log('⚠️ perfilRoutes não encontrado');
}

try {
  const resetRoutes = require('./routes/resetRoutes');
  app.use('/api/reset', resetRoutes);
} catch (e) {
  console.log('⚠️ resetRoutes não encontrado');
}

// ================================================================
// ROTAS DE SAÚDE E STATUS
// ================================================================

// Rota raiz
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    mensagem: 'Servidor Dogueria está funcionando',
    database: 'PostgreSQL',
    timestamp: new Date().toISOString(),
    usuario: req.session.usuario || null
  });
});

// Health check
app.get('/health', async (req, res) => {
  try {
    const connectionTest = await db.testConnection();

    if (connectionTest) {
      res.status(200).json({
        status: 'ok',
        mensagem: 'Servidor e banco de dados funcionando',
        database: 'PostgreSQL',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        status: 'erro',
        mensagem: 'Problema na conexão com o banco de dados',
        database: 'PostgreSQL',
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('❌ Erro no health check:', error);
    res.status(500).json({
      status: 'erro',
      mensagem: 'Erro interno do servidor',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// ================================================================
// TRATAMENTO DE ERROS
// ================================================================

// Middleware global de tratamento de erros
app.use((err, req, res, next) => {
  console.error('❌ Erro não tratado:', err);

  res.status(500).json({
    status: 'erro',
    mensagem: 'Erro interno do servidor',
    details: process.env.NODE_ENV === 'development' ? err.message : undefined,
    timestamp: new Date().toISOString()
  });
});

// Middleware para rotas não encontradas (404)
app.use('*', (req, res) => {
  res.status(404).json({
    status: 'erro',
    mensagem: 'Rota não encontrada',
    path: req.originalUrl,
    timestamp: new Date().toISOString()
  });
});

// ================================================================
// INICIALIZAÇÃO DO SERVIDOR
// ================================================================

const startServer = async () => {
  try {
    console.log('\n🔍 Testando conexão com PostgreSQL...');
    const connectionTest = await db.testConnection();

    if (!connectionTest) {
      console.error('❌ Falha na conexão com PostgreSQL');
      process.exit(1);
    }

    console.log('✅ PostgreSQL conectado com sucesso');

    app.listen(PORT, HOST, () => {
      console.log(`\n🚀 Servidor Dogueria rodando em http://${HOST}:${PORT}`);
      console.log(`📊 Health check disponível em http://${HOST}:${PORT}/health`);
      console.log(`🗄️ Banco de dados: PostgreSQL`);
      console.log(`🌍 Ambiente: ${process.env.NODE_ENV || 'development'}\n`);
    });

  } catch (error) {
    console.error('❌ Erro ao iniciar o servidor:', error);
    process.exit(1);
  }
};

// Tratamento de sinais para encerramento graceful
process.on('SIGINT', async () => {
  console.log('\n🔴 Encerrando servidor...');

  try {
    await db.pool.end();
    console.log('✅ Conexões com PostgreSQL encerradas');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao encerrar conexões:', error);
    process.exit(1);
  }
});

process.on('SIGTERM', async () => {
  console.log('\n🔴 SIGTERM recebido, encerrando servidor...');

  try {
    await db.pool.end();
    console.log('✅ Conexões com PostgreSQL encerradas');
    process.exit(0);
  } catch (error) {
    console.error('❌ Erro ao encerrar conexões:', error);
    process.exit(1);
  }
});

// Iniciar o servidor
startServer();

module.exports = app;
