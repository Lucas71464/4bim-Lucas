const db = require('../database.js');

// Listar todos os clientes
exports.listarClientes = async (req, res) => {
  try {
    const result = await db.query(
      'SELECT c.id, c.usuario_id, c.nome, c.telefone, c.endereco, c.data_criacao, u.nome_usuario, u.email_usuario FROM clientes c LEFT JOIN usuarios u ON c.usuario_id = u.id ORDER BY c.id'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar clientes:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Obter cliente por ID
exports.obterCliente = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(
      'SELECT c.id, c.usuario_id, c.nome, c.telefone, c.endereco, c.data_criacao, u.nome_usuario, u.email_usuario FROM clientes c LEFT JOIN usuarios u ON c.usuario_id = u.id WHERE c.id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao obter cliente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Criar novo cliente
exports.criarCliente = async (req, res) => {
  try {
    const { usuario_id, nome, telefone, endereco } = req.body;

    if (!nome) {
      return res.status(400).json({
        error: 'Nome é obrigatório'
      });
    }

    const result = await db.query(
      'INSERT INTO clientes (usuario_id, nome, telefone, endereco) VALUES ($1, $2, $3, $4) RETURNING id, usuario_id, nome, telefone, endereco, data_criacao',
      [usuario_id || null, nome, telefone || null, endereco || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao criar cliente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Atualizar cliente
exports.atualizarCliente = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { nome, telefone, endereco } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(
      'UPDATE clientes SET nome = $1, telefone = $2, endereco = $3 WHERE id = $4 RETURNING id, usuario_id, nome, telefone, endereco, data_criacao',
      [nome || null, telefone || null, endereco || null, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar cliente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Deletar cliente
exports.deletarCliente = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(
      'DELETE FROM clientes WHERE id = $1 RETURNING id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Cliente não encontrado' });
    }

    res.json({ message: 'Cliente deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar cliente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

