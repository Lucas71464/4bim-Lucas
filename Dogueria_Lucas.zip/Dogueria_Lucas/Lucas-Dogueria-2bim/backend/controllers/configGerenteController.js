const db = require('../database.js');

// Obter configurações do gerente logado
exports.getConfiguracoes = async (req, res) => {
  try {
    const usuarioId = req.session.usuario.id;

    const result = await db.query(
      'SELECT margem_lucro_padrao, limite_desconto_maximo FROM configuracoes_gerente WHERE usuario_id = $1',
      [usuarioId]
    );

    if (result.rows.length === 0) {
      // Se não existir, retorna as configurações padrão
      return res.json({
        usuario_id: usuarioId,
        margem_lucro_padrao: 30.00,
        limite_desconto_maximo: 10.00
      });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao obter configurações do gerente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Atualizar ou criar configurações do gerente logado
exports.salvarConfiguracoes = async (req, res) => {
  try {
    const usuarioId = req.session.usuario.id;
    const { margem_lucro_padrao, limite_desconto_maximo } = req.body;

    if (typeof margem_lucro_padrao !== 'number' || typeof limite_desconto_maximo !== 'number') {
      return res.status(400).json({ error: 'Dados de configuração inválidos. Margem e Limite devem ser números.' });
    }

    // Usar UPSERT (INSERT ON CONFLICT UPDATE)
    const result = await db.query(
      `INSERT INTO configuracoes_gerente (usuario_id, margem_lucro_padrao, limite_desconto_maximo, atualizado_em)
       VALUES ($1, $2, $3, now())
       ON CONFLICT (usuario_id) DO UPDATE
       SET margem_lucro_padrao = $2, limite_desconto_maximo = $3, atualizado_em = now()
       RETURNING *`,
      [usuarioId, margem_lucro_padrao, limite_desconto_maximo]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao salvar configurações do gerente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Deletar (resetar) configurações do gerente logado
exports.deletarConfiguracoes = async (req, res) => {
  try {
    const usuarioId = req.session.usuario.id;

    const result = await db.query(
      'DELETE FROM configuracoes_gerente WHERE usuario_id = $1 RETURNING usuario_id',
      [usuarioId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Configurações não encontradas para este gerente' });
    }

    res.json({ message: 'Configurações resetadas com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar configurações do gerente:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};
