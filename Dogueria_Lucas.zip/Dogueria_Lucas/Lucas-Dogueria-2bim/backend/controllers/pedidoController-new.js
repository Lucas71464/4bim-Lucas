const db = require('../database.js');

// GET /api/pedidos - Listar pedidos do usuário logado
exports.listOrders = async (req, res) => {
  try {
    console.log('📋 GET /api/pedidos');
    const usuarioId = req.session.usuario?.id;

    if (!usuarioId) {
      return res.status(401).json({ status: 'erro', mensagem: 'Não autenticado' });
    }

    // Se for gerente, listar todos os pedidos; caso contrário, apenas seus pedidos
    const isManager = req.session.usuario?.cargo === 'gerente';

    let query = 'SELECT id, usuario_id, valor_total, metodo_pagamento, status, criado_em FROM pedidos';
    const params = [];

    if (!isManager) {
      query += ' WHERE usuario_id = $1 ORDER BY criado_em DESC';
      params.push(usuarioId);
    } else {
      query += ' ORDER BY criado_em DESC';
    }

    const result = await db.query(query, params);

    // Para cada pedido, buscar os itens
    const pedidosComItens = await Promise.all(
      result.rows.map(async (pedido) => {
        const itensResult = await db.query(
          'SELECT id, produto_id, quantidade, preco_unit FROM itens_pedido WHERE pedido_id = $1',
          [pedido.id]
        );
        return {
          ...pedido,
          itens: itensResult.rows
        };
      })
    );

    res.json({
      status: 'ok',
      pedidos: pedidosComItens
    });
  } catch (error) {
    console.error('❌ Erro em listOrders:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao listar pedidos' });
  }
};

// GET /api/pedidos/:id - Obter um pedido específico
exports.getOrderById = async (req, res) => {
  try {
    console.log('👁️ GET /api/pedidos/:id');
    const { id } = req.params;
    const usuarioId = req.session.usuario?.id;
    const isManager = req.session.usuario?.cargo === 'gerente';

    const result = await db.query(
      'SELECT id, usuario_id, valor_total, metodo_pagamento, status, criado_em FROM pedidos WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Pedido não encontrado' });
    }

    const pedido = result.rows[0];

    // Verificar permissão
    if (!isManager && pedido.usuario_id !== usuarioId) {
      return res.status(403).json({ status: 'erro', mensagem: 'Acesso negado' });
    }

    // Buscar itens do pedido
    const itensResult = await db.query(
      'SELECT id, produto_id, quantidade, preco_unit FROM itens_pedido WHERE pedido_id = $1',
      [id]
    );

    res.json({
      status: 'ok',
      pedido: {
        ...pedido,
        itens: itensResult.rows
      }
    });
  } catch (error) {
    console.error('❌ Erro em getOrderById:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao obter pedido' });
  }
};

// POST /api/pedidos - Criar novo pedido com transação
exports.createOrder = async (req, res) => {
  try {
    console.log('➕ POST /api/pedidos');
    const usuarioId = req.session.usuario?.id;

    if (!usuarioId) {
      return res.status(401).json({ status: 'erro', mensagem: 'Não autenticado' });
    }

    const { itens, valor_total, metodo_pagamento, troco_para } = req.body;

    // Validações
    if (!itens || !Array.isArray(itens) || itens.length === 0) {
      return res.status(400).json({ status: 'erro', mensagem: 'Itens do pedido são obrigatórios' });
    }

    if (!valor_total || isNaN(valor_total) || valor_total <= 0) {
      return res.status(400).json({ status: 'erro', mensagem: 'Valor total deve ser um número positivo' });
    }

    if (!metodo_pagamento || !['pix', 'cartao', 'dinheiro'].includes(metodo_pagamento)) {
      return res.status(400).json({ status: 'erro', mensagem: 'Método de pagamento inválido (pix, cartao ou dinheiro)' });
    }

    // Se for dinheiro, validar troco_para
    if (metodo_pagamento === 'dinheiro' && troco_para !== undefined) {
      if (isNaN(troco_para) || troco_para < valor_total) {
        return res.status(400).json({ status: 'erro', mensagem: 'Valor para troco deve ser maior ou igual ao valor total' });
      }
    }

    // Usar transação para inserir pedido e itens
    const resultado = await db.transaction(async (client) => {
      // Inserir pedido
      const pedidoResult = await client.query(
        'INSERT INTO pedidos (usuario_id, valor_total, metodo_pagamento, troco_para, status) VALUES ($1, $2, $3, $4, $5) RETURNING id, usuario_id, valor_total, metodo_pagamento, status, criado_em',
        [usuarioId, parseFloat(valor_total), metodo_pagamento, troco_para || null, 'pendente']
      );

      const pedido = pedidoResult.rows[0];
      console.log('📝 Pedido criado:', pedido.id);

      // Inserir itens do pedido
      const itensInseridos = [];
      for (const item of itens) {
        if (!item.produto_id || !item.quantidade || !item.preco_unit) {
          throw new Error('Cada item deve ter produto_id, quantidade e preco_unit');
        }

        const itemResult = await client.query(
          'INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unit) VALUES ($1, $2, $3, $4) RETURNING id, produto_id, quantidade, preco_unit',
          [pedido.id, item.produto_id, item.quantidade, parseFloat(item.preco_unit)]
        );

        itensInseridos.push(itemResult.rows[0]);
      }

      console.log('✅ Itens inseridos:', itensInseridos.length);

      return {
        ...pedido,
        itens: itensInseridos
      };
    });

    res.status(201).json({
      status: 'ok',
      mensagem: 'Pedido criado com sucesso',
      pedido: resultado
    });
  } catch (error) {
    console.error('❌ Erro em createOrder:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao criar pedido: ' + error.message });
  }
};

// PUT /api/pedidos/:id/status - Atualizar status do pedido (apenas gerentes)
exports.updateOrderStatus = async (req, res) => {
  try {
    console.log('✏️ PUT /api/pedidos/:id/status');
    const { id } = req.params;
    const { status } = req.body;

    // Validar status
    const statusValidos = ['pendente', 'confirmado', 'preparando', 'pronto', 'entregue', 'cancelado'];
    if (!status || !statusValidos.includes(status)) {
      return res.status(400).json({ status: 'erro', mensagem: 'Status inválido' });
    }

    // Verificar se o pedido existe
    const pedidoCheck = await db.query('SELECT id FROM pedidos WHERE id = $1', [id]);
    if (pedidoCheck.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Pedido não encontrado' });
    }

    // Atualizar status
    const result = await db.query(
      'UPDATE pedidos SET status = $1, atualizado_em = now() WHERE id = $2 RETURNING id, usuario_id, valor_total, metodo_pagamento, status, criado_em, atualizado_em',
      [status, id]
    );

    console.log('✅ Status do pedido atualizado:', id, '->', status);

    res.json({
      status: 'ok',
      mensagem: 'Status do pedido atualizado com sucesso',
      pedido: result.rows[0]
    });
  } catch (error) {
    console.error('❌ Erro em updateOrderStatus:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao atualizar status do pedido' });
  }
};
