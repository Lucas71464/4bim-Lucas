const db = require('../database.js');

// Listar todos os itens de pedido (com informações de pedido e produto)
exports.listarItensPedido = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT ip.id, ip.pedido_id, ip.produto_id, ip.quantidade, ip.preco_unitario, ip.subtotal,
             prod.nome as produto_nome, 
             ped.cliente_id, 
             ped.status as pedido_status
      FROM itens_pedido ip
      LEFT JOIN produtos prod ON ip.produto_id = prod.id
      LEFT JOIN pedidos ped ON ip.pedido_id = ped.id
      ORDER BY ip.id
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar itens de pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Listar itens de um pedido específico
exports.listarItensPorPedido = async (req, res) => {
  try {
    const pedidoId = parseInt(req.params.pedido_id);

    if (isNaN(pedidoId)) {
      return res.status(400).json({ error: 'Pedido ID deve ser um número válido' });
    }

    const result = await db.query(`
      SELECT ip.id, ip.pedido_id, ip.produto_id, ip.quantidade, ip.preco_unitario, ip.subtotal,
             prod.nome as produto_nome, prod.preco as produto_preco_atual
      FROM itens_pedido ip
      LEFT JOIN produtos prod ON ip.produto_id = prod.id
      WHERE ip.pedido_id = $1
      ORDER BY ip.id
    `, [pedidoId]);
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar itens do pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Obter item de pedido por ID
exports.obterItemPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(`
      SELECT ip.id, ip.pedido_id, ip.produto_id, ip.quantidade, ip.preco_unitario, ip.subtotal,
             prod.nome as produto_nome
      FROM itens_pedido ip
      LEFT JOIN produtos prod ON ip.produto_id = prod.id
      WHERE ip.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Item de pedido não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao obter item de pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Criar novo item de pedido
exports.criarItemPedido = async (req, res) => {
  try {
    const { pedido_id, produto_id, quantidade, preco_unitario } = req.body;

    if (!pedido_id || !produto_id || !quantidade || preco_unitario === undefined) {
      return res.status(400).json({ 
        error: 'Pedido, produto, quantidade e preço unitário são obrigatórios' 
      });
    }

    // Validar tipos
    const pedidoIdNum = parseInt(pedido_id);
    const produtoIdNum = parseInt(produto_id);
    const quantidadeNum = parseInt(quantidade);
    const precoUnitarioNum = parseFloat(preco_unitario);

    if (isNaN(pedidoIdNum) || isNaN(produtoIdNum) || isNaN(quantidadeNum) || isNaN(precoUnitarioNum)) {
      return res.status(400).json({ error: 'IDs, quantidade e preço devem ser números válidos' });
    }

    if (quantidadeNum <= 0 || precoUnitarioNum < 0) {
      return res.status(400).json({ error: 'Quantidade deve ser positiva e preço não-negativo' });
    }

    // Verificar se pedido existe
    const pedidoExists = await db.query('SELECT id FROM pedidos WHERE id = $1', [pedidoIdNum]);
    if (pedidoExists.rows.length === 0) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }

    // Verificar se produto existe
    const produtoExists = await db.query('SELECT id FROM produtos WHERE id = $1', [produtoIdNum]);
    if (produtoExists.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    // Calcular subtotal
    const subtotal = quantidadeNum * precoUnitarioNum;

    const result = await db.query(
      'INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario, subtotal) VALUES ($1, $2, $3, $4, $5) RETURNING id, pedido_id, produto_id, quantidade, preco_unitario, subtotal',
      [pedidoIdNum, produtoIdNum, quantidadeNum, precoUnitarioNum, subtotal]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao criar item de pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Atualizar item de pedido
exports.atualizarItemPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { pedido_id, produto_id, quantidade, preco_unitario } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    // Verificar se item existe
    const itemExists = await db.query('SELECT pedido_id, produto_id FROM itens_pedido WHERE id = $1', [id]);
    if (itemExists.rows.length === 0) {
      return res.status(404).json({ error: 'Item de pedido não encontrado' });
    }

    // Verificar se pedido existe (se foi alterado)
    if (pedido_id && pedido_id !== itemExists.rows[0].pedido_id) {
      const pedidoExists = await db.query('SELECT id FROM pedidos WHERE id = $1', [pedido_id]);
      if (pedidoExists.rows.length === 0) {
        return res.status(404).json({ error: 'Pedido não encontrado' });
      }
    }

    // Verificar se produto existe (se foi alterado)
    if (produto_id && produto_id !== itemExists.rows[0].produto_id) {
      const produtoExists = await db.query('SELECT id FROM produtos WHERE id = $1', [produto_id]);
      if (produtoExists.rows.length === 0) {
        return res.status(404).json({ error: 'Produto não encontrado' });
      }
    }

    // Preparar valores para update
    const newPedidoId = pedido_id || itemExists.rows[0].pedido_id;
    const newProdutoId = produto_id || itemExists.rows[0].produto_id;
    const newQuantidade = quantidade !== undefined ? quantidade : null;
    const newPrecoUnitario = preco_unitario !== undefined ? preco_unitario : null;

    // Buscar valores atuais se não forem fornecidos
    let finalQuantidade = newQuantidade;
    let finalPrecoUnitario = newPrecoUnitario;

    if (!finalQuantidade || !finalPrecoUnitario) {
      const currentItem = await db.query('SELECT quantidade, preco_unitario FROM itens_pedido WHERE id = $1', [id]);
      finalQuantidade = finalQuantidade || currentItem.rows[0].quantidade;
      finalPrecoUnitario = finalPrecoUnitario || currentItem.rows[0].preco_unitario;
    }

    const subtotal = finalQuantidade * finalPrecoUnitario;

    const result = await db.query(
      'UPDATE itens_pedido SET pedido_id = $1, produto_id = $2, quantidade = $3, preco_unitario = $4, subtotal = $5 WHERE id = $6 RETURNING id, pedido_id, produto_id, quantidade, preco_unitario, subtotal',
      [newPedidoId, newProdutoId, finalQuantidade, finalPrecoUnitario, subtotal, id]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar item de pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Deletar item de pedido
exports.deletarItemPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query('DELETE FROM itens_pedido WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Item de pedido não encontrado' });
    }

    res.json({ message: 'Item de pedido deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar item de pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

