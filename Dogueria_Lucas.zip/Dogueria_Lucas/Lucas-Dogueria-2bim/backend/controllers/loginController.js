const db = require('../database.js');
const bcrypt = require('bcrypt');

// This controller provides legacy-named endpoints but works against the
// current schema (columns: nome, email, senha_hash, cargo, ativo, criado_em)

// Verificar se usuário está logado (verifica sessão)
exports.verificaSeUsuarioEstaLogado = (req, res) => {
  console.log('loginController - Acessando rota /verificaSeUsuarioEstaLogado');
  const usuarioSessao = req.session && req.session.usuario;
  if (usuarioSessao) {
    // return just a display name for compatibility
    return res.json({ status: 'ok', nome: usuarioSessao.nome });
  }
  return res.json({ status: 'nao_logado' });
};

// Verificar senha (fazer login) - compatible with legacy route names
exports.verificarSenha = async (req, res) => {
  // Accept both 'email'/'senha' and 'email_usuario'/'senha_usuario'
  const email = req.body.email || req.body.email_usuario;
  const senha = req.body.senha || req.body.senha_usuario || req.body.password;

  if (!email || !senha) {
    return res.status(400).json({ status: 'erro', mensagem: 'Email e senha são obrigatórios' });
  }

  try {
    // Query using current schema columns
    const sql = `SELECT id, nome, email, senha_hash, cargo, avatar_url FROM usuarios WHERE email = $1 AND ativo = true`;
    const result = await db.query(sql, [email]);

    if (result.rows.length === 0) {
      return res.json({ status: 'senha_incorreta' });
    }

    const user = result.rows[0];
    const senhaArmazenada = user.senha_hash;
    let senhaValida = false;
    if (typeof senhaArmazenada === 'string' && senhaArmazenada.startsWith('$2')) {
      senhaValida = await bcrypt.compare(senha, senhaArmazenada);
    } else {
      senhaValida = senha === senhaArmazenada;
    }

    if (!senhaValida) return res.json({ status: 'senha_incorreta' });

    // Save to session
    req.session.usuario = {
      id: user.id,
      nome: user.nome,
      email: user.email,
      cargo: user.cargo,
      avatar_url: user.avatar_url || null
    };

    // Set cookie for frontend convenience (non httpOnly)
    res.cookie('usuarioLogado', JSON.stringify(req.session.usuario), {
      httpOnly: false,
      sameSite: 'Lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000
    });

    res.cookie('usuarioRole', req.session.usuario.cargo || 'cliente', {
      httpOnly: false,
      sameSite: 'Lax',
      path: '/',
      maxAge: 24 * 60 * 60 * 1000
    });

    console.log('✅ Login (legacy) bem-sucedido:', user.email);
    return res.json({ status: 'ok', nome: user.nome, role: user.cargo, usuarioId: user.id });
  } catch (err) {
    console.error('❌ Erro ao verificar senha:', err);
    return res.status(500).json({ status: 'erro', mensagem: err.message });
  }
};

// Logout (legacy)
exports.logout = (req, res) => {
  try {
    req.session && req.session.destroy && req.session.destroy(() => {});
  } catch (e) {
    // ignore
  }
  res.clearCookie('usuarioLogado', { path: '/' });
  res.clearCookie('usuarioRole', { path: '/' });
  console.log("✅ Logout (legacy) executado");
  res.json({ status: 'deslogado' });
};

// Listar usuários (legacy) - uses current schema
exports.listarUsuarios = async (req, res) => {
  try {
    const result = await db.query('SELECT id, nome, email, cargo, criado_em, ativo FROM usuarios ORDER BY id');
    res.json(result.rows);
  } catch (err) {
    console.error('❌ Erro ao listar usuários:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// verificarEmail (legacy-compatible)
exports.verificarEmail = async (req, res) => {
  const { email } = req.body || {};
  if (!email) return res.status(400).json({ status: 'erro', mensagem: 'Email é obrigatório' });
  try {
    const result = await db.query('SELECT nome FROM usuarios WHERE email = $1', [email]);
    if (result.rows.length > 0) return res.json({ status: 'existe', nome: result.rows[0].nome });
    return res.json({ status: 'nao_encontrado' });
  } catch (err) {
    console.error('❌ Erro em verificarEmail:', err);
    return res.status(500).json({ status: 'erro', mensagem: err.message });
  }
};

// criarUsuario (legacy-compatible) - will hash password and insert
exports.criarUsuario = async (req, res) => {
  try {
    const nome = req.body.nome || req.body.nome_usuario || req.body.name || null;
    const email = req.body.email || req.body.email_usuario || null;
    const senha = req.body.senha || req.body.senha_usuario || req.body.password || null;
    const cargo = req.body.role || req.body.cargo || 'cliente';

    if (!nome || !email || !senha) return res.status(400).json({ error: 'Nome, email e senha são obrigatórios' });

    const saltRounds = parseInt(process.env.SALT_ROUNDS || '10');
    const senhaHash = await bcrypt.hash(senha, saltRounds);

    const insert = await db.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo, criado_em) VALUES ($1, $2, $3, $4, true, now()) RETURNING id, nome, email, cargo, criado_em',
      [nome, email, senhaHash, cargo]
    );

    res.status(201).json(insert.rows[0]);
  } catch (err) {
    console.error('❌ Erro ao criar usuário:', err);
    if (err.code === '23505') return res.status(400).json({ error: 'Email já está em uso' });
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// obterUsuario por id
exports.obterUsuario = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'ID inválido' });
    const result = await db.query('SELECT id, nome, email, cargo, criado_em, ativo FROM usuarios WHERE id = $1', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error('❌ Erro ao obter usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// obterUsuarioPorEmail
exports.obterUsuarioPorEmail = async (req, res) => {
  try {
    const email = req.params.email;
    if (!email) return res.status(400).json({ error: 'Email é obrigatório' });
    const result = await db.query('SELECT id, nome, email, cargo, criado_em, ativo FROM usuarios WHERE email = $1', [email]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error('❌ Erro ao obter usuário por email:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// atualizarUsuario
exports.atualizarUsuario = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'ID inválido' });
    const { nome, email, cargo, ativo } = req.body;
    const result = await db.query('UPDATE usuarios SET nome = $1, email = $2, cargo = $3, ativo = $4, atualizado_em = now() WHERE id = $5 RETURNING id, nome, email, cargo, criado_em, ativo', [nome || null, email || null, cargo || null, ativo !== undefined ? ativo : true, id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error('❌ Erro ao atualizar usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// atualizarSenha
exports.atualizarSenha = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { senha_atual, nova_senha } = req.body;
    if (isNaN(id) || !senha_atual || !nova_senha) return res.status(400).json({ error: 'Parâmetros inválidos' });
    const usuarioResult = await db.query('SELECT senha_hash FROM usuarios WHERE id = $1', [id]);
    if (usuarioResult.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    const senhaArmazenada = usuarioResult.rows[0].senha_hash;
    let valid = false;
    if (typeof senhaArmazenada === 'string' && senhaArmazenada.startsWith('$2')) valid = await bcrypt.compare(senha_atual, senhaArmazenada);
    else valid = senha_atual === senhaArmazenada;
    if (!valid) return res.status(400).json({ error: 'Senha atual incorreta' });
    const novaHash = await bcrypt.hash(nova_senha, parseInt(process.env.SALT_ROUNDS || '10'));
    const update = await db.query('UPDATE usuarios SET senha_hash = $1, atualizado_em = now() WHERE id = $2 RETURNING id, nome, email, cargo, criado_em', [novaHash, id]);
    res.json(update.rows[0]);
  } catch (err) {
    console.error('❌ Erro ao atualizar senha:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// deletarUsuario
exports.deletarUsuario = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: 'ID inválido' });
    const result = await db.query('UPDATE usuarios SET ativo = false, atualizado_em = now() WHERE id = $1 RETURNING id', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado' });
    res.json({ message: 'Usuário desativado com sucesso' });
  } catch (err) {
    console.error('❌ Erro ao deletar usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};
