const db = require('../database.js');

// Listar todos os produtos
exports.listarProdutos = async (req, res) => {
  try {
    // Ajustado para colunas existentes no schema: nome, descricao, ingredientes, preco, imagem_url, criado_em, ativo
    const result = await db.query(
      'SELECT id, nome, descricao, ingredientes, preco, imagem_url, criado_em, ativo FROM produtos WHERE ativo = true ORDER BY id'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar produtos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Obter produto por ID
exports.obterProduto = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(
      'SELECT id, nome, descricao, ingredientes, preco, imagem_url, criado_em, ativo FROM produtos WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao obter produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Criar novo produto
exports.criarProduto = async (req, res) => {
  try {
    // Ajustado para o schema atual (sem campo estoque)
    const { nome, preco, descricao, ingredientes, imagem_url } = req.body;

    if (!nome || preco === undefined) {
      return res.status(400).json({
        error: 'Nome e preço são obrigatórios'
      });
    }

    const precoNum = parseFloat(preco);
    if (isNaN(precoNum) || precoNum < 0) {
      return res.status(400).json({ error: 'Preço deve ser um número positivo' });
    }

    const result = await db.query(
      'INSERT INTO produtos (nome, descricao, ingredientes, preco, imagem_url, ativo, criado_em) VALUES ($1, $2, $3, $4, $5, true, now()) RETURNING id, nome, descricao, ingredientes, preco, imagem_url, criado_em, ativo',
      [nome, descricao || null, ingredientes || null, precoNum, imagem_url || null]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao criar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Atualizar produto
exports.atualizarProduto = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { nome, preco, descricao, ingredientes, imagem_url, ativo } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    // Montar query dinâmica baseada em quais campos estão sendo atualizados
    let updates = [];
    let values = [];
    let paramCount = 1;

    if (nome !== undefined) {
      updates.push(`nome = $${paramCount}`);
      values.push(nome);
      paramCount++;
    }

    if (preco !== undefined) {
      const precoNum = parseFloat(preco);
      if (isNaN(precoNum) || precoNum < 0) {
        return res.status(400).json({ error: 'Preço deve ser um número positivo' });
      }
      updates.push(`preco = $${paramCount}`);
      values.push(precoNum);
      paramCount++;
    }

    if (descricao !== undefined) {
      updates.push(`descricao = $${paramCount}`);
      values.push(descricao);
      paramCount++;
    }

    if (ingredientes !== undefined) {
      updates.push(`ingredientes = $${paramCount}`);
      values.push(ingredientes);
      paramCount++;
    }

    if (imagem_url !== undefined) {
      updates.push(`imagem_url = $${paramCount}`);
      values.push(imagem_url);
      paramCount++;
    }

    if (ativo !== undefined) {
      updates.push(`ativo = $${paramCount}`);
      values.push(ativo);
      paramCount++;
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'Nenhum campo para atualizar' });
    }

    values.push(id);

    const query = `UPDATE produtos SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING id, nome, descricao, ingredientes, preco, imagem_url, criado_em, atualizado_em, ativo`;

    const result = await db.query(query, values);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Deletar produto (soft delete - marca como inativo)
exports.deletarProduto = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(
      'UPDATE produtos SET ativo = false WHERE id = $1 RETURNING id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Produto não encontrado' });
    }

    res.json({ message: 'Produto deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar produto:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

