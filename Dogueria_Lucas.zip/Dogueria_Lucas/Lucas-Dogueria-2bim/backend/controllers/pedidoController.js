const db = require('../database.js');

// Listar todos os pedidos (com informações do usuário)
exports.listarPedidos = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT p.id, p.usuario_id, p.valor_total, p.metodo_pagamento, p.troco_para, p.status, p.criado_em, p.opcao_recebimento,
             u.nome as usuario_nome, u.email as usuario_email
      FROM pedidos p 
      LEFT JOIN usuarios u ON p.usuario_id = u.id 
      ORDER BY p.id DESC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar pedidos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Obter pedido por ID
exports.obterPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    const result = await db.query(`
      SELECT p.id, p.usuario_id, p.valor_total, p.metodo_pagamento, p.troco_para, p.status, p.criado_em, p.opcao_recebimento,
             u.nome as usuario_nome, u.email as usuario_email
      FROM pedidos p 
      LEFT JOIN usuarios u ON p.usuario_id = u.id 
      WHERE p.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }

    // Buscar itens do pedido
    const itens = await db.query(`
      SELECT ip.id, ip.produto_id, ip.quantidade, ip.preco_unit,
             pr.nome as produto_nome, pr.descricao as produto_descricao
      FROM itens_pedido ip
      LEFT JOIN produtos pr ON ip.produto_id = pr.id
      WHERE ip.pedido_id = $1
    `, [id]);

    const pedido = result.rows[0];
    pedido.itens = itens.rows;

    res.json(pedido);
  } catch (error) {
    console.error('❌ Erro ao obter pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Listar pedidos de um usuário específico
exports.listarPedidosPorUsuario = async (req, res) => {
  try {
    const usuarioId = parseInt(req.params.usuario_id);

    if (isNaN(usuarioId)) {
      return res.status(400).json({ error: 'Usuário ID deve ser um número válido' });
    }

    const result = await db.query(
      'SELECT id, usuario_id, valor_total, metodo_pagamento, troco_para, status, criado_em, opcao_recebimento FROM pedidos WHERE usuario_id = $1 ORDER BY criado_em DESC',
      [usuarioId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('❌ Erro ao listar pedidos do usuário:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Criar novo pedido com itens
exports.criarPedido = async (req, res) => {
  try {
    const { usuario_id, valor_total, metodo_pagamento, troco_para, opcao_recebimento, dados_cartao, itens } = req.body;

    if (!opcao_recebimento) {
      return res.status(400).json({ error: 'Opção de recebimento é obrigatória' });
    }

    // Apenas para simulação: logar os dados do cartão, mas não armazenar no BD
    if (metodo_pagamento === 'cartao' && dados_cartao) {
      console.log('💳 Dados do Cartão Recebidos (SIMULAÇÃO):', dados_cartao);
    }

    if (!usuario_id) {
      return res.status(400).json({ error: 'Usuário é obrigatório' });
    }

    if (!metodo_pagamento) {
      return res.status(400).json({ error: 'Método de pagamento é obrigatório' });
    }

    if (!itens || !Array.isArray(itens) || itens.length === 0) {
      return res.status(400).json({ error: 'Itens do pedido são obrigatórios' });
    }

    // Verificar se usuário existe
    const usuarioExists = await db.query('SELECT id FROM usuarios WHERE id = $1 AND ativo = true', [usuario_id]);
    if (usuarioExists.rows.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    // Usar transação para criar pedido e itens
    const result = await db.transaction(async (client) => {
      // Criar pedido
      const pedidoResult = await client.query(
        'INSERT INTO pedidos (usuario_id, valor_total, metodo_pagamento, troco_para, status, criado_em, opcao_recebimento) VALUES ($1, $2, $3, $4, $5, now(), $6) RETURNING id, usuario_id, valor_total, metodo_pagamento, troco_para, status, criado_em, opcao_recebimento',
        [usuario_id, valor_total, metodo_pagamento, troco_para || null, 'pendente', opcao_recebimento]
      );

      const pedido = pedidoResult.rows[0];

      // Criar itens do pedido
      for (const item of itens) {
        await client.query(
          'INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unit, criado_em) VALUES ($1, $2, $3, $4, now())',
          [pedido.id, item.produto_id, item.quantidade, item.preco_unit]
        );
      }

      return pedido;
    });

    res.status(201).json(result);
  } catch (error) {
    console.error('❌ Erro ao criar pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor', message: error.message });
  }
};

// Atualizar status do pedido
exports.atualizarPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status } = req.body;

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    if (!status) {
      return res.status(400).json({ error: 'Status é obrigatório' });
    }

    const result = await db.query(
      'UPDATE pedidos SET status = $1, atualizado_em = now() WHERE id = $2 RETURNING id, usuario_id, valor_total, metodo_pagamento, troco_para, status, criado_em, atualizado_em',
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao atualizar pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Deletar pedido
exports.deletarPedido = async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    if (isNaN(id)) {
      return res.status(400).json({ error: 'ID deve ser um número válido' });
    }

    // Os itens_pedido serão deletados automaticamente por causa do ON DELETE CASCADE
    const result = await db.query('DELETE FROM pedidos WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Pedido não encontrado' });
    }

    res.json({ message: 'Pedido deletado com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar pedido:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};
