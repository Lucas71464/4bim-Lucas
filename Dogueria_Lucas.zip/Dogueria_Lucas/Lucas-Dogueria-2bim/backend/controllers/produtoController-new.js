const db = require('../database.js');

// GET /api/produtos - Listar todos os produtos (públicos)
exports.listProducts = async (req, res) => {
  try {
    console.log('📋 GET /api/produtos');

    const result = await db.query(
      'SELECT id, nome, descricao, ingredientes, preco, imagem_url, criado_em FROM produtos WHERE ativo = true ORDER BY nome'
    );

    res.json({
      status: 'ok',
      produtos: result.rows
    });
  } catch (error) {
    console.error('❌ Erro em listProducts:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao listar produtos' });
  }
};

// GET /api/produtos/:id - Obter dados de um produto
exports.getProductById = async (req, res) => {
  try {
    console.log('👁️ GET /api/produtos/:id');
    const { id } = req.params;

    const result = await db.query(
      'SELECT id, nome, descricao, ingredientes, preco, imagem_url, ativo, criado_em FROM produtos WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Produto não encontrado' });
    }

    res.json({
      status: 'ok',
      produto: result.rows[0]
    });
  } catch (error) {
    console.error('❌ Erro em getProductById:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao obter produto' });
  }
};

// POST /api/produtos - Criar novo produto (apenas gerentes)
exports.createProduct = async (req, res) => {
  try {
    console.log('➕ POST /api/produtos');
    const { nome, descricao, ingredientes, preco, imagem_url } = req.body;

    // Validações
    if (!nome || !preco) {
      return res.status(400).json({ status: 'erro', mensagem: 'Nome e preço são obrigatórios' });
    }

    if (isNaN(preco) || preco <= 0) {
      return res.status(400).json({ status: 'erro', mensagem: 'Preço deve ser um número positivo' });
    }

    // Inserir novo produto
    const result = await db.query(
      'INSERT INTO produtos (nome, descricao, ingredientes, preco, imagem_url) VALUES ($1, $2, $3, $4, $5) RETURNING id, nome, descricao, ingredientes, preco, imagem_url, criado_em',
      [nome, descricao || null, ingredientes || null, parseFloat(preco), imagem_url || null]
    );

    const produto = result.rows[0];
    console.log('✅ Produto criado:', produto.id);

    res.status(201).json({
      status: 'ok',
      mensagem: 'Produto criado com sucesso',
      produto
    });
  } catch (error) {
    console.error('❌ Erro em createProduct:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao criar produto' });
  }
};

// PUT /api/produtos/:id - Atualizar produto (apenas gerentes)
exports.updateProduct = async (req, res) => {
  try {
    console.log('✏️ PUT /api/produtos/:id');
    const { id } = req.params;
    const { nome, descricao, ingredientes, preco, imagem_url, ativo } = req.body;

    // Verificar se o produto existe
    const prodCheck = await db.query('SELECT id FROM produtos WHERE id = $1', [id]);
    if (prodCheck.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Produto não encontrado' });
    }

    // Construir query dinâmico
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (nome) {
      updates.push(`nome = $${paramCount}`);
      values.push(nome);
      paramCount++;
    }

    if (descricao !== undefined) {
      updates.push(`descricao = $${paramCount}`);
      values.push(descricao);
      paramCount++;
    }

    if (ingredientes !== undefined) {
      updates.push(`ingredientes = $${paramCount}`);
      values.push(ingredientes);
      paramCount++;
    }

    if (preco !== undefined) {
      if (isNaN(preco) || preco <= 0) {
        return res.status(400).json({ status: 'erro', mensagem: 'Preço deve ser um número positivo' });
      }
      updates.push(`preco = $${paramCount}`);
      values.push(parseFloat(preco));
      paramCount++;
    }

    if (imagem_url !== undefined) {
      updates.push(`imagem_url = $${paramCount}`);
      values.push(imagem_url);
      paramCount++;
    }

    if (ativo !== undefined) {
      updates.push(`ativo = $${paramCount}`);
      values.push(ativo);
      paramCount++;
    }

    if (updates.length === 0) {
      return res.status(400).json({ status: 'erro', mensagem: 'Nenhum campo para atualizar' });
    }

    updates.push(`atualizado_em = now()`);
    values.push(id);

    const query = `UPDATE produtos SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING id, nome, descricao, ingredientes, preco, imagem_url, ativo, criado_em, atualizado_em`;

    const result = await db.query(query, values);

    console.log('✅ Produto atualizado:', id);

    res.json({
      status: 'ok',
      mensagem: 'Produto atualizado com sucesso',
      produto: result.rows[0]
    });
  } catch (error) {
    console.error('❌ Erro em updateProduct:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao atualizar produto' });
  }
};

// DELETE /api/produtos/:id - Deletar produto (apenas gerentes)
exports.deleteProduct = async (req, res) => {
  try {
    console.log('🗑️ DELETE /api/produtos/:id');
    const { id } = req.params;

    // Verificar se o produto existe
    const prodCheck = await db.query('SELECT id FROM produtos WHERE id = $1', [id]);
    if (prodCheck.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Produto não encontrado' });
    }

    // Soft delete - apenas marcar como inativo
    await db.query('UPDATE produtos SET ativo = false WHERE id = $1', [id]);

    console.log('✅ Produto desativado:', id);

    res.json({
      status: 'ok',
      mensagem: 'Produto desativado com sucesso'
    });
  } catch (error) {
    console.error('❌ Erro em deleteProduct:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao deletar produto' });
  }
};
