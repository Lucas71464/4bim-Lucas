const db = require('../database.js');

// Obter configurações do usuário logado
exports.getConfiguracoes = async (req, res) => {
  try {
    const usuarioId = req.session.usuario.id;

    const result = await db.query(
      'SELECT tema_preferido, receber_notificacoes FROM configuracoes_usuario WHERE usuario_id = $1',
      [usuarioId]
    );

    if (result.rows.length === 0) {
      // Se não existir, retorna as configurações padrão
      return res.json({
        usuario_id: usuarioId,
        tema_preferido: 'claro',
        receber_notificacoes: true
      });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao obter configurações:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Atualizar ou criar configurações do usuário logado
exports.salvarConfiguracoes = async (req, res) => {
  try {
    const usuarioId = req.session.usuario.id;
    const { tema_preferido, receber_notificacoes } = req.body;

    if (!tema_preferido || typeof receber_notificacoes !== 'boolean') {
      return res.status(400).json({ error: 'Dados de configuração inválidos' });
    }

    // Usar UPSERT (INSERT ON CONFLICT UPDATE)
    const result = await db.query(
      `INSERT INTO configuracoes_usuario (usuario_id, tema_preferido, receber_notificacoes, atualizado_em)
       VALUES ($1, $2, $3, now())
       ON CONFLICT (usuario_id) DO UPDATE
       SET tema_preferido = $2, receber_notificacoes = $3, atualizado_em = now()
       RETURNING *`,
      [usuarioId, tema_preferido, receber_notificacoes]
    );

    res.json(result.rows[0]);
  } catch (error) {
    console.error('❌ Erro ao salvar configurações:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Gerente pode deletar (resetar) configurações de qualquer usuário
exports.deletarConfiguracoes = async (req, res) => {
  try {
    const usuarioId = parseInt(req.params.usuario_id);

    if (isNaN(usuarioId)) {
      return res.status(400).json({ error: 'ID do usuário inválido' });
    }

    const result = await db.query(
      'DELETE FROM configuracoes_usuario WHERE usuario_id = $1 RETURNING usuario_id',
      [usuarioId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Configurações não encontradas para este usuário' });
    }

    res.json({ message: 'Configurações resetadas com sucesso' });
  } catch (error) {
    console.error('❌ Erro ao deletar configurações:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};
