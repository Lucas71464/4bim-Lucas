const { query } = require('../database');

// Listar todos os perfis (com informações do usuário)
const listarPerfis = async (req, res) => {
  try {
    const result = await query(`
      SELECT p.*, u.username, u.role 
      FROM perfis p 
      LEFT JOIN usuarios u ON p.usuario_id = u.id 
      ORDER BY p.id
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao listar perfis:', error);
    res.status(500).json({ success: false, message: 'Erro ao listar perfis.' });
  }
};

// Buscar perfil por ID
const buscarPerfil = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query(`
      SELECT p.*, u.username, u.role 
      FROM perfis p 
      LEFT JOIN usuarios u ON p.usuario_id = u.id 
      WHERE p.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Perfil não encontrado.' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao buscar perfil:', error);
    res.status(500).json({ success: false, message: 'Erro ao buscar perfil.' });
  }
};

// Buscar perfil por usuario_id (relacionamento 1:1)
const buscarPerfilPorUsuario = async (req, res) => {
  try {
    const { usuario_id } = req.params;
    const result = await query(`
      SELECT p.*, u.username, u.role 
      FROM perfis p 
      LEFT JOIN usuarios u ON p.usuario_id = u.id 
      WHERE p.usuario_id = $1
    `, [usuario_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Perfil não encontrado para este usuário.' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao buscar perfil por usuário:', error);
    res.status(500).json({ success: false, message: 'Erro ao buscar perfil por usuário.' });
  }
};

// Criar novo perfil
const criarPerfil = async (req, res) => {
  try {
    const { usuario_id, nome_completo, cpf, data_nascimento, foto_url } = req.body;

    if (!usuario_id) {
      return res.status(400).json({ success: false, message: 'Usuário é obrigatório.' });
    }

    // Verificar se usuário existe
    const usuarioExists = await query('SELECT * FROM usuarios WHERE id = $1', [usuario_id]);
    if (usuarioExists.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    // Verificar se já existe perfil para este usuário (relacionamento 1:1)
    const perfilExists = await query('SELECT * FROM perfis WHERE usuario_id = $1', [usuario_id]);
    if (perfilExists.rows.length > 0) {
      return res.status(409).json({ 
        success: false, 
        message: 'Já existe um perfil para este usuário. Use atualização ao invés de criação.' 
      });
    }

    const result = await query(
      'INSERT INTO perfis (usuario_id, nome_completo, cpf, data_nascimento, foto_url) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [usuario_id, nome_completo || null, cpf || null, data_nascimento || null, foto_url || null]
    );

    res.status(201).json({ success: true, perfil: result.rows[0] });
  } catch (error) {
    console.error('Erro ao criar perfil:', error);
    
    // Tratamento especial para violação de UNIQUE constraint
    if (error.code === '23505') {
      if (error.constraint === 'perfis_usuario_id_key') {
        return res.status(409).json({ success: false, message: 'Já existe um perfil para este usuário.' });
      }
      if (error.constraint === 'perfis_cpf_key') {
        return res.status(409).json({ success: false, message: 'CPF já cadastrado.' });
      }
    }
    
    res.status(500).json({ success: false, message: 'Erro ao criar perfil.' });
  }
};

// Atualizar perfil
const atualizarPerfil = async (req, res) => {
  try {
    const { id } = req.params;
    const { usuario_id, nome_completo, cpf, data_nascimento, foto_url } = req.body;

    // Verificar se perfil existe
    const perfilExists = await query('SELECT * FROM perfis WHERE id = $1', [id]);
    if (perfilExists.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Perfil não encontrado.' });
    }

    // Se usuario_id foi alterado, verificar se novo usuário existe e não tem perfil
    if (usuario_id && usuario_id !== perfilExists.rows[0].usuario_id) {
      const usuarioExists = await query('SELECT * FROM usuarios WHERE id = $1', [usuario_id]);
      if (usuarioExists.rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
      }

      const outroPerfilExists = await query('SELECT * FROM perfis WHERE usuario_id = $1 AND id != $2', [usuario_id, id]);
      if (outroPerfilExists.rows.length > 0) {
        return res.status(409).json({ success: false, message: 'Este usuário já possui um perfil.' });
      }
    }

    const result = await query(
      'UPDATE perfis SET usuario_id = $1, nome_completo = $2, cpf = $3, data_nascimento = $4, foto_url = $5 WHERE id = $6 RETURNING *',
      [
        usuario_id || perfilExists.rows[0].usuario_id,
        nome_completo !== undefined ? nome_completo : perfilExists.rows[0].nome_completo,
        cpf !== undefined ? cpf : perfilExists.rows[0].cpf,
        data_nascimento !== undefined ? data_nascimento : perfilExists.rows[0].data_nascimento,
        foto_url !== undefined ? foto_url : perfilExists.rows[0].foto_url,
        id
      ]
    );

    res.json({ success: true, perfil: result.rows[0] });
  } catch (error) {
    console.error('Erro ao atualizar perfil:', error);
    
    // Tratamento especial para violação de UNIQUE constraint
    if (error.code === '23505') {
      if (error.constraint === 'perfis_cpf_key') {
        return res.status(409).json({ success: false, message: 'CPF já cadastrado.' });
      }
    }
    
    res.status(500).json({ success: false, message: 'Erro ao atualizar perfil.' });
  }
};

// Deletar perfil
const deletarPerfil = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query('DELETE FROM perfis WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Perfil não encontrado.' });
    }

    res.json({ success: true, message: 'Perfil deletado com sucesso.' });
  } catch (error) {
    console.error('Erro ao deletar perfil:', error);
    res.status(500).json({ success: false, message: 'Erro ao deletar perfil.' });
  }
};

module.exports = {
  listarPerfis,
  buscarPerfil,
  buscarPerfilPorUsuario,
  criarPerfil,
  atualizarPerfil,
  deletarPerfil
};

