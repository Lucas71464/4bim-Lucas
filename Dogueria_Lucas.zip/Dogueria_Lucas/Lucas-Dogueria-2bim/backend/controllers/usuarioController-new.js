const db = require('../database.js');
const bcrypt = require('bcrypt');

// GET /api/usuarios - Listar todos os usuários (apenas gerentes)
exports.listUsers = async (req, res) => {
  try {
    console.log('📋 GET /api/usuarios');

    const result = await db.query(
      'SELECT id, nome, email, cargo, avatar_url, ativo, criado_em FROM usuarios ORDER BY criado_em DESC'
    );

    res.json({
      status: 'ok',
      usuarios: result.rows
    });
  } catch (error) {
    console.error('❌ Erro em listUsers:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao listar usuários' });
  }
};

// GET /api/usuarios/:id - Obter dados de um usuário
exports.getUserById = async (req, res) => {
  try {
    console.log('👤 GET /api/usuarios/:id');
    const { id } = req.params;

    const result = await db.query(
      'SELECT id, nome, email, cargo, avatar_url, ativo, criado_em FROM usuarios WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Usuário não encontrado' });
    }

    res.json({
      status: 'ok',
      usuario: result.rows[0]
    });
  } catch (error) {
    console.error('❌ Erro em getUserById:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao obter usuário' });
  }
};

// POST /api/usuarios - Criar novo usuário (apenas gerentes)
exports.createUser = async (req, res) => {
  try {
    console.log('➕ POST /api/usuarios');
    const { nome, email, senha, cargo } = req.body;

    // Validações
    if (!nome || !email || !senha) {
      return res.status(400).json({ status: 'erro', mensagem: 'Nome, email e senha são obrigatórios' });
    }

    if (senha.length < 6) {
      return res.status(400).json({ status: 'erro', mensagem: 'Senha deve ter pelo menos 6 caracteres' });
    }

    // Validar cargo
    const cargoValido = cargo && (cargo === 'cliente' || cargo === 'gerente') ? cargo : 'cliente';

    // Verificar se email já existe
    const emailCheck = await db.query('SELECT id FROM usuarios WHERE email = $1', [email]);
    if (emailCheck.rows.length > 0) {
      return res.status(409).json({ status: 'erro', mensagem: 'Email já cadastrado' });
    }

    // Hash de senha
    const saltRounds = parseInt(process.env.SALT_ROUNDS || '10');
    const senhaHash = await bcrypt.hash(senha, saltRounds);

    // Inserir novo usuário
    const result = await db.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo) VALUES ($1, $2, $3, $4) RETURNING id, nome, email, cargo, avatar_url, criado_em',
      [nome, email, senhaHash, cargoValido]
    );

    const usuario = result.rows[0];
    console.log('✅ Usuário criado:', usuario.id);

    res.status(201).json({
      status: 'ok',
      mensagem: 'Usuário criado com sucesso',
      usuario
    });
  } catch (error) {
    console.error('❌ Erro em createUser:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao criar usuário' });
  }
};

// PUT /api/usuarios/:id - Atualizar usuário (apenas gerentes ou o próprio usuário)
exports.updateUser = async (req, res) => {
  try {
    console.log('✏️ PUT /api/usuarios/:id');
    const { id } = req.params;
    const { nome, cargo, avatar_url, ativo } = req.body;

    // Verificar se o usuário existe
    const userCheck = await db.query('SELECT id FROM usuarios WHERE id = $1', [id]);
    if (userCheck.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Usuário não encontrado' });
    }

    // Construir query dinâmico
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (nome) {
      updates.push(`nome = $${paramCount}`);
      values.push(nome);
      paramCount++;
    }

    if (cargo) {
      const cargoValido = cargo === 'cliente' || cargo === 'gerente' ? cargo : 'cliente';
      updates.push(`cargo = $${paramCount}`);
      values.push(cargoValido);
      paramCount++;
    }

    if (avatar_url !== undefined) {
      updates.push(`avatar_url = $${paramCount}`);
      values.push(avatar_url);
      paramCount++;
    }

    if (ativo !== undefined) {
      updates.push(`ativo = $${paramCount}`);
      values.push(ativo);
      paramCount++;
    }

    if (updates.length === 0) {
      return res.status(400).json({ status: 'erro', mensagem: 'Nenhum campo para atualizar' });
    }

    updates.push(`atualizado_em = now()`);
    values.push(id);

    const query = `UPDATE usuarios SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING id, nome, email, cargo, avatar_url, ativo, criado_em, atualizado_em`;

    const result = await db.query(query, values);

    console.log('✅ Usuário atualizado:', id);

    res.json({
      status: 'ok',
      mensagem: 'Usuário atualizado com sucesso',
      usuario: result.rows[0]
    });
  } catch (error) {
    console.error('❌ Erro em updateUser:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao atualizar usuário' });
  }
};

// DELETE /api/usuarios/:id - Deletar usuário (apenas gerentes)
exports.deleteUser = async (req, res) => {
  try {
    console.log('🗑️ DELETE /api/usuarios/:id');
    const { id } = req.params;

    // Verificar se o usuário existe
    const userCheck = await db.query('SELECT id FROM usuarios WHERE id = $1', [id]);
    if (userCheck.rows.length === 0) {
      return res.status(404).json({ status: 'erro', mensagem: 'Usuário não encontrado' });
    }

    // Soft delete - apenas marcar como inativo
    await db.query('UPDATE usuarios SET ativo = false WHERE id = $1', [id]);

    console.log('✅ Usuário desativado:', id);

    res.json({
      status: 'ok',
      mensagem: 'Usuário desativado com sucesso'
    });
  } catch (error) {
    console.error('❌ Erro em deleteUser:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao deletar usuário' });
  }
};
