const { query } = require('../database');
const bcrypt = require('bcrypt');

// Listar todos os usuários
const listarUsuarios = async (req, res) => {
  try {
    const result = await query('SELECT id, nome, email, cargo, ativo, criado_em FROM usuarios ORDER BY id');
    res.json(result.rows);
  } catch (error) {
    console.error('Erro ao listar usuários:', error);
    res.status(500).json({ success: false, message: 'Erro ao listar usuários.' });
  }
};

// Buscar usuário por ID
const buscarUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await query('SELECT id, nome, email, cargo, ativo, avatar_url, criado_em FROM usuarios WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erro ao buscar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro ao buscar usuário.' });
  }
};

// Criar novo usuário
const criarUsuario = async (req, res) => {
  try {
    const { nome, email, senha, cargo, avatar_url } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ success: false, message: 'Nome, email e senha são obrigatórios.' });
    }

    // Verificar se email já existe
    const userExists = await query('SELECT * FROM usuarios WHERE email = $1', [email]);
    if (userExists.rows.length > 0) {
      return res.status(409).json({ success: false, message: 'Email já está em uso.' });
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(senha, 10);
    const userCargo = cargo || 'cliente';

    const result = await query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo, avatar_url, ativo, criado_em) VALUES ($1, $2, $3, $4, $5, true, now()) RETURNING id, nome, email, cargo, avatar_url, criado_em',
      [nome, email, hashedPassword, userCargo, avatar_url || null]
    );

    res.status(201).json({ success: true, user: result.rows[0] });
  } catch (error) {
    console.error('Erro ao criar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro ao criar usuário.' });
  }
};

// Atualizar usuário
const atualizarUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, email, senha, cargo, avatar_url, ativo } = req.body;

    // Verificar se usuário existe
    const userExists = await query('SELECT * FROM usuarios WHERE id = $1', [id]);
    if (userExists.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    const currentUser = userExists.rows[0];
    let updateQuery = 'UPDATE usuarios SET nome = $1, email = $2, cargo = $3, avatar_url = $4, ativo = $5, atualizado_em = now()';
    let params = [
      nome || currentUser.nome, 
      email || currentUser.email, 
      cargo || currentUser.cargo,
      avatar_url !== undefined ? avatar_url : currentUser.avatar_url,
      ativo !== undefined ? ativo : currentUser.ativo
    ];

    // Se senha foi fornecida, atualizar também
    if (senha) {
      const hashedPassword = await bcrypt.hash(senha, 10);
      updateQuery += ', senha_hash = $6 WHERE id = $7 RETURNING id, nome, email, cargo, avatar_url, ativo, criado_em';
      params.push(hashedPassword, id);
    } else {
      updateQuery += ' WHERE id = $6 RETURNING id, nome, email, cargo, avatar_url, ativo, criado_em';
      params.push(id);
    }

    const result = await query(updateQuery, params);
    res.json({ success: true, user: result.rows[0] });
  } catch (error) {
    console.error('Erro ao atualizar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro ao atualizar usuário.' });
  }
};

// Deletar usuário (soft delete)
const deletarUsuario = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await query('UPDATE usuarios SET ativo = false, atualizado_em = now() WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuário não encontrado.' });
    }

    res.json({ success: true, message: 'Usuário desativado com sucesso.' });
  } catch (error) {
    console.error('Erro ao deletar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro ao deletar usuário.' });
  }
};

module.exports = {
  listarUsuarios,
  buscarUsuario,
  criarUsuario,
  atualizarUsuario,
  deletarUsuario
};
