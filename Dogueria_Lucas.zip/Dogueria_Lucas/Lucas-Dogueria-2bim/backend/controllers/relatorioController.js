const db = require('../database.js');

// Relatório 1: Vendas por Mês (Formato JSON para visualização)
exports.vendasPorMesJSON = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        TO_CHAR(criado_em, 'YYYY-MM') AS mes_ano,
        SUM(valor_total) AS total_vendas,
        COUNT(id) AS total_pedidos
      FROM pedidos
      WHERE status = 'entregue'
      GROUP BY mes_ano
      ORDER BY mes_ano DESC
    `);

    const relatorio = {
      titulo: 'Relatório de Vendas por Mês',
      data_geracao: new Date().toLocaleString('pt-BR'),
      dados: result.rows.map(row => ({
        mes_ano: row.mes_ano,
        total_vendas: parseFloat(row.total_vendas).toFixed(2),
        total_pedidos: parseInt(row.total_pedidos)
      }))
    };

    // Renderizar um HTML simples para impressão
    let html = `
      <!DOCTYPE html>
      <html lang="pt-br">
      <head>
          <meta charset="UTF-8">
          <title>${relatorio.titulo}</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { text-align: center; }
              p { text-align: center; }
              table { width: 80%; margin: 20px auto; border-collapse: collapse; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              .total { font-weight: bold; background-color: #e6e6e6; }
              @media print {
                  body { margin: 0; }
                  table { width: 100%; }
              }
          </style>
      </head>
      <body>
          <h1>${relatorio.titulo}</h1>
          <p>Gerado em: ${relatorio.data_geracao}</p>
          <table>
              <thead>
                  <tr>
                      <th>Mês/Ano</th>
                      <th>Total de Vendas (R$)</th>
                      <th>Total de Pedidos</th>
                  </tr>
              </thead>
              <tbody>
    `;

    let totalGeral = 0;
    let totalPedidosGeral = 0;

    relatorio.dados.forEach(item => {
      html += `
        <tr>
          <td>${item.mes_ano}</td>
          <td>${item.total_vendas.replace('.', ',')}</td>
          <td>${item.total_pedidos}</td>
        </tr>
      `;
      totalGeral += parseFloat(item.total_vendas);
      totalPedidosGeral += item.total_pedidos;
    });

    html += `
              <tr class="total">
                  <td>TOTAL GERAL</td>
                  <td>${totalGeral.toFixed(2).replace('.', ',')}</td>
                  <td>${totalPedidosGeral}</td>
              </tr>
              </tbody>
          </table>
      </body>
      </html>
    `;

    res.json(relatorio);

  } catch (error) {
    console.error('❌ Erro ao gerar relatório de vendas por mês (JSON):', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Relatório 1: Vendas por Mês (Formato HTML para impressão)
exports.vendasPorMesHTML = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        TO_CHAR(criado_em, 'YYYY-MM') AS mes_ano,
        SUM(valor_total) AS total_vendas,
        COUNT(id) AS total_pedidos
      FROM pedidos
      WHERE status = 'entregue'
      GROUP BY mes_ano
      ORDER BY mes_ano DESC
    `);

    const relatorio = {
      titulo: 'Relatório de Vendas por Mês',
      data_geracao: new Date().toLocaleString('pt-BR'),
      dados: result.rows.map(row => ({
        mes_ano: row.mes_ano,
        total_vendas: parseFloat(row.total_vendas).toFixed(2),
        total_pedidos: parseInt(row.total_pedidos)
      }))
    };

    // Renderizar um HTML simples para impressão
    let html = `
      <!DOCTYPE html>
      <html lang="pt-br">
      <head>
          <meta charset="UTF-8">
          <title>${relatorio.titulo}</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { text-align: center; }
              p { text-align: center; }
              table { width: 80%; margin: 20px auto; border-collapse: collapse; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              .total { font-weight: bold; background-color: #e6e6e6; }
              @media print {
                  body { margin: 0; }
                  table { width: 100%; }
              }
          </style>
      </head>
      <body>
          <h1>${relatorio.titulo}</h1>
          <p>Gerado em: ${relatorio.data_geracao}</p>
          <table>
              <thead>
                  <tr>
                      <th>Mês/Ano</th>
                      <th>Total de Vendas (R$)</th>
                      <th>Total de Pedidos</th>
                  </tr>
              </thead>
              <tbody>
    `;

    let totalGeral = 0;
    let totalPedidosGeral = 0;

    relatorio.dados.forEach(item => {
      html += `
        <tr>
          <td>${item.mes_ano}</td>
          <td>${item.total_vendas.replace('.', ',')}</td>
          <td>${item.total_pedidos}</td>
        </tr>
      `;
      totalGeral += parseFloat(item.total_vendas);
      totalPedidosGeral += item.total_pedidos;
    });

    html += `
                <tr class="total">
                  <td>TOTAL GERAL</td>
                  <td>${totalGeral.toFixed(2).replace('.', ',')}</td>
                  <td>${totalPedidosGeral}</td>
              </tr>
              </tbody>
          </table>
      </body>
      </html>
    `;

    res.send(html);

  } catch (error) {
    console.error('❌ Erro ao gerar relatório de vendas por mês (HTML):', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Relatório 2: Clientes Mais Ativos (Formato JSON para visualização)
exports.clientesMaisAtivosJSON = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        u.id,
        u.nome,
        u.email,
        COUNT(p.id) AS total_pedidos,
        SUM(p.valor_total) AS valor_total_gasto
      FROM usuarios u
      JOIN pedidos p ON u.id = p.usuario_id
      WHERE p.status = 'entregue'
      GROUP BY u.id, u.nome, u.email
      ORDER BY total_pedidos DESC, valor_total_gasto DESC
      LIMIT 10
    `);

    const relatorio = {
      titulo: 'Relatório de 10 Clientes Mais Ativos',
      data_geracao: new Date().toLocaleString('pt-BR'),
      dados: result.rows.map(row => ({
        id: row.id,
        nome: row.nome,
        email: row.email,
        total_pedidos: parseInt(row.total_pedidos),
        valor_total_gasto: parseFloat(row.valor_total_gasto).toFixed(2)
      }))
    };

    res.json(relatorio);

  } catch (error) {
    console.error('❌ Erro ao gerar relatório de clientes mais ativos:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};

// Relatório 2: Clientes Mais Ativos (Formato HTML para impressão)
exports.clientesMaisAtivosHTML = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        u.id,
        u.nome,
        u.email,
        COUNT(p.id) AS total_pedidos,
        SUM(p.valor_total) AS valor_total_gasto
      FROM usuarios u
      JOIN pedidos p ON u.id = p.usuario_id
      WHERE p.status = 'entregue'
      GROUP BY u.id, u.nome, u.email
      ORDER BY total_pedidos DESC, valor_total_gasto DESC
      LIMIT 10
    `);

    const relatorio = {
      titulo: 'Relatório de 10 Clientes Mais Ativos',
      data_geracao: new Date().toLocaleString('pt-BR'),
      dados: result.rows.map(row => ({
        id: row.id,
        nome: row.nome,
        email: row.email,
        total_pedidos: parseInt(row.total_pedidos),
        valor_total_gasto: parseFloat(row.valor_total_gasto).toFixed(2)
      }))
    };

    // Renderizar um HTML simples para impressão
    let html = `
      <!DOCTYPE html>
      <html lang="pt-br">
      <head>
          <meta charset="UTF-8">
          <title>${relatorio.titulo}</title>
          <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              h1 { text-align: center; }
              p { text-align: center; }
              table { width: 80%; margin: 20px auto; border-collapse: collapse; }
              th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
              th { background-color: #f2f2f2; }
              .total { font-weight: bold; background-color: #e6e6e6; }
              @media print {
                  body { margin: 0; }
                  table { width: 100%; }
              }
          </style>
      </head>
      <body>
          <h1>${relatorio.titulo}</h1>
          <p>Gerado em: ${relatorio.data_geracao}</p>
          <table>
              <thead>
                  <tr>
                      <th>#</th>
                      <th>Nome do Cliente</th>
                      <th>Email</th>
                      <th>Total de Pedidos</th>
                      <th>Total Gasto (R$)</th>
                  </tr>
              </thead>
              <tbody>
    `;

    relatorio.dados.forEach((item, index) => {
      html += `
        <tr>
          <td>${index + 1}</td>
          <td>${item.nome}</td>
          <td>${item.email}</td>
          <td>${item.total_pedidos}</td>
          <td>${item.valor_total_gasto.replace('.', ',')}</td>
        </tr>
      `;
    });

    html += `
              </tbody>
          </table>
      </body>
      </html>
    `;

    res.send(html);

  } catch (error) {
    console.error('❌ Erro ao gerar relatório de clientes mais ativos (HTML):', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
};
