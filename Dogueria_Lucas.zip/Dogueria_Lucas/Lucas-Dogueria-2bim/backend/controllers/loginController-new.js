const db = require('../database.js');
const bcrypt = require('bcrypt');

// Detectar schema do banco de dados
let _userSchema = null;
async function detectUserSchema() {
  if (_userSchema) return _userSchema;
  try {
    const res = await db.query("SELECT column_name FROM information_schema.columns WHERE table_name = 'usuarios'");
    const cols = res.rows.map(r => r.column_name);
    _userSchema = {
      cols,
      hasNome: cols.includes('nome'),
      hasEmail: cols.includes('email'),
      hasSenhaHash: cols.includes('senha_hash'),
      hasCargo: cols.includes('cargo'),
      hasAvatarUrl: cols.includes('avatar_url')
    };
  } catch (err) {
    console.error('❌ Erro detectando schema de usuarios:', err);
    _userSchema = { cols: [], hasNome: false, hasEmail: false, hasSenhaHash: false };
  }
  return _userSchema;
}

// REGISTRO - Criar novo usuário
exports.register = async (req, res) => {
  try {
    console.log('📝 POST /api/register - Novo registro');
    const { nome, email, senha } = req.body;

    // Validações
    if (!nome || !email || !senha) {
      return res.status(400).json({ status: 'erro', mensagem: 'Nome, email e senha são obrigatórios' });
    }

    if (senha.length < 6) {
      return res.status(400).json({ status: 'erro', mensagem: 'Senha deve ter pelo menos 6 caracteres' });
    }

    // Verificar se email já existe
    const emailCheck = await db.query('SELECT id FROM usuarios WHERE email = $1', [email]);
    if (emailCheck.rows.length > 0) {
      return res.status(409).json({ status: 'erro', mensagem: 'Email já cadastrado' });
    }

    // Hash de senha
    const saltRounds = parseInt(process.env.SALT_ROUNDS || '10');
    const senhaHash = await bcrypt.hash(senha, saltRounds);

    // Inserir novo usuário
    const result = await db.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo) VALUES ($1, $2, $3, $4) RETURNING id, nome, email, cargo, avatar_url',
      [nome, email, senhaHash, 'cliente']
    );

    const usuario = result.rows[0];
    console.log('✅ Usuário criado:', usuario.id);

    // Salvar na sessão
    req.session.usuario = {
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      cargo: usuario.cargo,
      avatar_url: usuario.avatar_url
    };

    // Salvar cookie
    res.cookie('usuarioLogado', JSON.stringify(req.session.usuario), {
      httpOnly: false,
      sameSite: 'Lax',
      path: '/'
    });

    res.status(201).json({
      status: 'ok',
      mensagem: 'Usuário registrado com sucesso',
      usuario: req.session.usuario
    });
  } catch (error) {
    console.error('❌ Erro em register:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao registrar usuário' });
  }
};

// LOGIN - Autenticar usuário
exports.login = async (req, res) => {
  try {
    console.log('🔑 POST /api/login');
    const { email, senha } = req.body;

    // Validações
    if (!email || !senha) {
      return res.status(400).json({ status: 'erro', mensagem: 'Email e senha são obrigatórios' });
    }

    // Buscar usuário
    const result = await db.query(
      'SELECT id, nome, email, senha_hash, cargo, avatar_url FROM usuarios WHERE email = $1 AND ativo = true',
      [email]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ status: 'erro', mensagem: 'Email ou senha incorretos' });
    }

    const usuario = result.rows[0];

    // Validar senha
    const senhaValida = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaValida) {
      return res.status(401).json({ status: 'erro', mensagem: 'Email ou senha incorretos' });
    }

    // Salvar na sessão
    req.session.usuario = {
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      cargo: usuario.cargo,
      avatar_url: usuario.avatar_url
    };

    // Salvar cookie
    res.cookie('usuarioLogado', JSON.stringify(req.session.usuario), {
      httpOnly: false,
      sameSite: 'Lax',
      path: '/'
    });

    console.log('✅ Login bem-sucedido:', usuario.email);

    res.json({
      status: 'ok',
      mensagem: 'Login realizado com sucesso',
      usuario: req.session.usuario
    });
  } catch (error) {
    console.error('❌ Erro em login:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao fazer login' });
  }
};

// LOGOUT - Desautenticar usuário
exports.logout = async (req, res) => {
  try {
    console.log('🚪 POST /api/logout');

    // Limpar sessão
    req.session.destroy((err) => {
      if (err) {
        console.error('❌ Erro ao destruir sessão:', err);
        return res.status(500).json({ status: 'erro', mensagem: 'Erro ao fazer logout' });
      }

      // Limpar cookie
      res.clearCookie('usuarioLogado', { path: '/' });

      console.log('✅ Logout bem-sucedido');

      res.json({
        status: 'ok',
        mensagem: 'Logout realizado com sucesso'
      });
    });
  } catch (error) {
    console.error('❌ Erro em logout:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao fazer logout' });
  }
};

// GET /api/me - Retornar dados do usuário logado
exports.getCurrentUser = async (req, res) => {
  try {
    console.log('👤 GET /api/me');

    if (!req.session.usuario) {
      return res.status(401).json({ status: 'erro', mensagem: 'Não autenticado' });
    }

    res.json({
      status: 'ok',
      usuario: req.session.usuario
    });
  } catch (error) {
    console.error('❌ Erro em getCurrentUser:', error);
    res.status(500).json({ status: 'erro', mensagem: 'Erro ao obter dados do usuário' });
  }
};
