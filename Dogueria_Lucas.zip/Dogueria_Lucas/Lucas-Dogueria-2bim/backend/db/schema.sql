-- Schema para Dogueria - Banco de Dados PostgreSQL
-- Criação de tabelas necessárias para autenticação, produtos, pedidos e itens_pedido

CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(200) UNIQUE NOT NULL,
  senha_hash VARCHAR(200) NOT NULL,
  cargo VARCHAR(50) NOT NULL DEFAULT 'cliente',
  avatar_url TEXT,
  ativo BOOLEAN DEFAULT true,
  criado_em TIMESTAMP DEFAULT now(),
  atualizado_em TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS produtos (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(200) NOT NULL,
  descricao TEXT,
  ingredientes TEXT,
  preco NUMERIC(10,2) NOT NULL,
  imagem_url TEXT,
  ativo BOOLEAN DEFAULT true,
  criado_em TIMESTAMP DEFAULT now(),
  atualizado_em TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pedidos (
  id SERIAL PRIMARY KEY,
  usuario_id INTEGER REFERENCES usuarios(id),
  valor_total NUMERIC(10,2) NOT NULL,
  metodo_pagamento VARCHAR(50) NOT NULL,
  opcao_recebimento VARCHAR(50) NOT NULL,
  troco_para NUMERIC(10,2),
  status VARCHAR(50) DEFAULT 'pendente',
  criado_em TIMESTAMP DEFAULT now(),
  atualizado_em TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS itens_pedido (
  id SERIAL PRIMARY KEY,
  pedido_id INTEGER NOT NULL REFERENCES pedidos(id) ON DELETE CASCADE,
  produto_id INTEGER REFERENCES produtos(id),
  quantidade INTEGER NOT NULL,
  preco_unit NUMERIC(10,2) NOT NULL,
  criado_em TIMESTAMP DEFAULT now()
);

-- Tabela de sessões para express-session com connect-pg-simple
CREATE TABLE IF NOT EXISTS session (
  sid VARCHAR NOT NULL COLLATE "default",
  sess JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL,
  PRIMARY KEY (sid)
);

CREATE INDEX IF NOT EXISTS IDX_session_expire ON session (expire);

-- Tabela de Configurações do Usuário (Relacionamento 1:1 com usuarios)
CREATE TABLE IF NOT EXISTS configuracoes_usuario (
    usuario_id INTEGER PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    tema_preferido VARCHAR(50) DEFAULT 'claro', -- Exemplo de campo 1:1
    receber_notificacoes BOOLEAN DEFAULT TRUE,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Configurações do Gerente (Relacionamento 1:1 com usuarios onde cargo='gerente')
CREATE TABLE IF NOT EXISTS configuracoes_gerente (
    usuario_id INTEGER PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    margem_lucro_padrao NUMERIC(5, 2) DEFAULT 30.00, -- Exemplo de campo gerencial
    limite_desconto_maximo NUMERIC(5, 2) DEFAULT 10.00,
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ***************************************************************************************************
-- * ATUALIZAÇÕES DE SCHEMA (ALTER TABLE) PARA GARANTIR COMPATIBILIDADE COM VERSÕES ANTERIORES *
-- ***************************************************************************************************

-- Adicionar coluna opcao_recebimento na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='opcao_recebimento') THEN
        ALTER TABLE pedidos ADD COLUMN opcao_recebimento VARCHAR(50) NOT NULL DEFAULT 'retirada';
    END IF;
END $$;

-- Adicionar coluna avatar_url na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='avatar_url') THEN
        ALTER TABLE usuarios ADD COLUMN avatar_url TEXT;
    END IF;
END $$;

-- Adicionar coluna ingredientes na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='ingredientes') THEN
        ALTER TABLE produtos ADD COLUMN ingredientes TEXT;
    END IF;
END $$;

-- Adicionar coluna ativo na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='ativo') THEN
        ALTER TABLE produtos ADD COLUMN ativo BOOLEAN DEFAULT true;
    END IF;
END $$;

-- Adicionar coluna ativo na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='ativo') THEN
        ALTER TABLE usuarios ADD COLUMN ativo BOOLEAN DEFAULT true;
    END IF;
END $$;

-- Adicionar coluna atualizado_em na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='atualizado_em') THEN
        ALTER TABLE pedidos ADD COLUMN atualizado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna atualizado_em na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='atualizado_em') THEN
        ALTER TABLE usuarios ADD COLUMN atualizado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna atualizado_em na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='atualizado_em') THEN
        ALTER TABLE produtos ADD COLUMN atualizado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna criado_em na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='criado_em') THEN
        ALTER TABLE itens_pedido ADD COLUMN criado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna criado_em na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='criado_em') THEN
        ALTER TABLE pedidos ADD COLUMN criado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna criado_em na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='criado_em') THEN
        ALTER TABLE produtos ADD COLUMN criado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna criado_em na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='criado_em') THEN
        ALTER TABLE usuarios ADD COLUMN criado_em TIMESTAMP DEFAULT now();
    END IF;
END $$;

-- Adicionar coluna imagem_url na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='imagem_url') THEN
        ALTER TABLE produtos ADD COLUMN imagem_url TEXT;
    END IF;
END $$;

-- Adicionar coluna troco_para na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='troco_para') THEN
        ALTER TABLE pedidos ADD COLUMN troco_para NUMERIC(10,2);
    END IF;
END $$;

-- Adicionar coluna status na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='status') THEN
        ALTER TABLE pedidos ADD COLUMN status VARCHAR(50) DEFAULT 'pendente';
    END IF;
END $$;

-- Adicionar coluna cargo na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='cargo') THEN
        ALTER TABLE usuarios ADD COLUMN cargo VARCHAR(50) DEFAULT 'cliente';
    END IF;
END $$;

-- Adicionar coluna metodo_pagamento na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='metodo_pagamento') THEN
        ALTER TABLE pedidos ADD COLUMN metodo_pagamento VARCHAR(50);
    END IF;
END $$;

-- Adicionar coluna valor_total na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='valor_total') THEN
        ALTER TABLE pedidos ADD COLUMN valor_total NUMERIC(10,2);
    END IF;
END $$;

-- Adicionar coluna usuario_id na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='usuario_id') THEN
        ALTER TABLE pedidos ADD COLUMN usuario_id INTEGER REFERENCES usuarios(id);
    END IF;
END $$;

-- Adicionar coluna preco na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='preco') THEN
        ALTER TABLE produtos ADD COLUMN preco NUMERIC(10,2);
    END IF;
END $$;

-- Adicionar coluna descricao na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='descricao') THEN
        ALTER TABLE produtos ADD COLUMN descricao TEXT;
    END IF;
END $$;

-- Adicionar coluna nome na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='nome') THEN
        ALTER TABLE produtos ADD COLUMN nome VARCHAR(200);
    END IF;
END $$;

-- Adicionar coluna senha_hash na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='senha_hash') THEN
        ALTER TABLE usuarios ADD COLUMN senha_hash VARCHAR(200);
    END IF;
END $$;

-- Adicionar coluna email na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='email') THEN
        ALTER TABLE usuarios ADD COLUMN email VARCHAR(200);
    END IF;
END $$;

-- Adicionar coluna nome na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='nome') THEN
        ALTER TABLE usuarios ADD COLUMN nome VARCHAR(150);
    END IF;
END $$;

-- Adicionar coluna preco_unit na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='preco_unit') THEN
        ALTER TABLE itens_pedido ADD COLUMN preco_unit NUMERIC(10,2);
    END IF;
END $$;

-- Adicionar coluna quantidade na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='quantidade') THEN
        ALTER TABLE itens_pedido ADD COLUMN quantidade INTEGER;
    END IF;
END $$;

-- Adicionar coluna produto_id na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='produto_id') THEN
        ALTER TABLE itens_pedido ADD COLUMN produto_id INTEGER REFERENCES produtos(id);
    END IF;
END $$;

-- Adicionar coluna pedido_id na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='pedido_id') THEN
        ALTER TABLE itens_pedido ADD COLUMN pedido_id INTEGER REFERENCES pedidos(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar coluna usuario_id na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_usuario' AND column_name='usuario_id') THEN
        ALTER TABLE configuracoes_usuario ADD COLUMN usuario_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar coluna tema_preferido na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_usuario' AND column_name='tema_preferido') THEN
        ALTER TABLE configuracoes_usuario ADD COLUMN tema_preferido VARCHAR(50) DEFAULT 'claro';
    END IF;
END $$;

-- Adicionar coluna receber_notificacoes na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_usuario' AND column_name='receber_notificacoes') THEN
        ALTER TABLE configuracoes_usuario ADD COLUMN receber_notificacoes BOOLEAN DEFAULT TRUE;
    END IF;
END $$;

-- Adicionar coluna atualizado_em na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_usuario' AND column_name='atualizado_em') THEN
        ALTER TABLE configuracoes_usuario ADD COLUMN atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    END IF;
END $$;

-- Adicionar coluna margem_lucro_padrao na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_gerente' AND column_name='margem_lucro_padrao') THEN
        ALTER TABLE configuracoes_gerente ADD COLUMN margem_lucro_padrao NUMERIC(5, 2) DEFAULT 30.00;
    END IF;
END $$;

-- Adicionar coluna limite_desconto_maximo na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_gerente' AND column_name='limite_desconto_maximo') THEN
        ALTER TABLE configuracoes_gerente ADD COLUMN limite_desconto_maximo NUMERIC(5, 2) DEFAULT 10.00;
    END IF;
END $$;

-- Adicionar coluna atualizado_em na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_gerente' AND column_name='atualizado_em') THEN
        ALTER TABLE configuracoes_gerente ADD COLUMN atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;
    END IF;
END $$;

-- Adicionar coluna usuario_id na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='configuracoes_gerente' AND column_name='usuario_id') THEN
        ALTER TABLE configuracoes_gerente ADD COLUMN usuario_id INTEGER REFERENCES usuarios(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'configuracoes_gerente'::regclass AND contype = 'p') THEN
        ALTER TABLE configuracoes_gerente ADD PRIMARY KEY (usuario_id);
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'configuracoes_usuario'::regclass AND contype = 'p') THEN
        ALTER TABLE configuracoes_usuario ADD PRIMARY KEY (usuario_id);
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'itens_pedido'::regclass AND contype = 'p') THEN
        ALTER TABLE itens_pedido ADD PRIMARY KEY (id);
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'pedidos'::regclass AND contype = 'p') THEN
        ALTER TABLE pedidos ADD PRIMARY KEY (id);
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela produtos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'produtos'::regclass AND contype = 'p') THEN
        ALTER TABLE produtos ADD PRIMARY KEY (id);
    END IF;
END $$;

-- Adicionar PRIMARY KEY na tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'usuarios'::regclass AND contype = 'p') THEN
        ALTER TABLE usuarios ADD PRIMARY KEY (id);
    END IF;
END $$;

-- Adicionar UNIQUE constraint na coluna email da tabela usuarios (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'usuarios'::regclass AND contype = 'u' AND conname = 'usuarios_email_key') THEN
        ALTER TABLE usuarios ADD UNIQUE (email);
    END IF;
END $$;

-- Adicionar FOREIGN KEY na tabela pedidos (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'pedidos'::regclass AND contype = 'f' AND conname = 'pedidos_usuario_id_fkey') THEN
        ALTER TABLE pedidos ADD FOREIGN KEY (usuario_id) REFERENCES usuarios(id);
    END IF;
END $$;

-- Adicionar FOREIGN KEY na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'itens_pedido'::regclass AND contype = 'f' AND conname = 'itens_pedido_pedido_id_fkey') THEN
        ALTER TABLE itens_pedido ADD FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar FOREIGN KEY na tabela itens_pedido (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'itens_pedido'::regclass AND contype = 'f' AND conname = 'itens_pedido_produto_id_fkey') THEN
        ALTER TABLE itens_pedido ADD FOREIGN KEY (produto_id) REFERENCES produtos(id);
    END IF;
END $$;

-- Adicionar FOREIGN KEY na tabela configuracoes_usuario (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'configuracoes_usuario'::regclass AND contype = 'f' AND conname = 'configuracoes_usuario_usuario_id_fkey') THEN
        ALTER TABLE configuracoes_usuario ADD FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar FOREIGN KEY na tabela configuracoes_gerente (se não existir)
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'configuracoes_gerente'::regclass AND contype = 'f' AND conname = 'configuracoes_gerente_usuario_id_fkey') THEN
        ALTER TABLE configuracoes_gerente ADD FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE;
    END IF;
END $$;

-- Adicionar NOT NULL para colunas essenciais (se não for NOT NULL)
DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='nome' AND is_nullable='YES') THEN
        ALTER TABLE usuarios ALTER COLUMN nome SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='email' AND is_nullable='YES') THEN
        ALTER TABLE usuarios ALTER COLUMN email SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='usuarios' AND column_name='senha_hash' AND is_nullable='YES') THEN
        ALTER TABLE usuarios ALTER COLUMN senha_hash SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='nome' AND is_nullable='YES') THEN
        ALTER TABLE produtos ALTER COLUMN nome SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='produtos' AND column_name='preco' AND is_nullable='YES') THEN
        ALTER TABLE produtos ALTER COLUMN preco SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='valor_total' AND is_nullable='YES') THEN
        ALTER TABLE pedidos ALTER COLUMN valor_total SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='metodo_pagamento' AND is_nullable='YES') THEN
        ALTER TABLE pedidos ALTER COLUMN metodo_pagamento SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='pedidos' AND column_name='opcao_recebimento' AND is_nullable='YES') THEN
        ALTER TABLE pedidos ALTER COLUMN opcao_recebimento SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='quantidade' AND is_nullable='YES') THEN
        ALTER TABLE itens_pedido ALTER COLUMN quantidade SET NOT NULL;
    END IF;
END $$;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='itens_pedido' AND column_name='preco_unit' AND is_nullable='YES') THEN
        ALTER TABLE itens_pedido ALTER COLUMN preco_unit SET NOT NULL;
    END IF;
END $$;

-- FIM DAS ATUALIZAÇÕES DE SCHEMA
-- ***************************************************************************************************

-- Criar índices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_pedidos_usuario_id ON pedidos(usuario_id);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_pedido_id ON itens_pedido(pedido_id);
CREATE INDEX IF NOT EXISTS idx_itens_pedido_produto_id ON itens_pedido(produto_id);
