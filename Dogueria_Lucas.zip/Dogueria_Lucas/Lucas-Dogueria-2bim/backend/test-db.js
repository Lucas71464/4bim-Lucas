import pg from "pg";
const { Pool } = pg;

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "dogueria_bd",
  password: "123456", // sua nova senha aqui
  port: 5432,
});

pool.connect()
  .then(() => {
    console.log("✅ Conexão com PostgreSQL bem-sucedida!");
    pool.end();
  })
  .catch(err => {
    console.error("❌ Erro na conexão:", err.message);
  });
