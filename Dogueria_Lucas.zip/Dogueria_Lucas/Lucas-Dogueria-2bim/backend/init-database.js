const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
require('dotenv').config();

// Configuração do banco
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'dogueria_db'
});

async function initDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('🔄 Iniciando configuração do banco de dados...\n');

    // 1. Executar schema
    console.log('📋 Criando tabelas...');
    const schemaSQL = fs.readFileSync(path.join(__dirname, 'db', 'schema.sql'), 'utf8');
    await client.query(schemaSQL);
    console.log('✅ Tabelas criadas com sucesso!\n');

    // 2. Verificar se já existem dados
    const checkUsers = await client.query('SELECT COUNT(*) FROM usuarios');
    const userCount = parseInt(checkUsers.rows[0].count);

    if (userCount > 0) {
      console.log('⚠️  Banco de dados já contém dados.');
      console.log(`   Usuários existentes: ${userCount}`);
      
      const checkProducts = await client.query('SELECT COUNT(*) FROM produtos');
      const productCount = parseInt(checkProducts.rows[0].count);
      console.log(`   Produtos existentes: ${productCount}\n`);
      
      return;
    }

    // 3. Criar usuário gerente
    console.log('👤 Criando usuário gerente...');
    const senhaGerente = 'admin123';
    const hashGerente = await bcrypt.hash(senhaGerente, 10);
    
    await client.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo, criado_em) VALUES ($1, $2, $3, $4, true, now())',
      ['Administrador', 'admin@dogueria.com', hashGerente, 'gerente']
    );
    console.log('✅ Usuário gerente criado!');
    console.log('   Email: admin@dogueria.com');
    console.log('   Senha: admin123\n');

    // 4. Criar usuário cliente de teste
    console.log('👤 Criando usuário cliente de teste...');
    const senhaCliente = 'cliente123';
    const hashCliente = await bcrypt.hash(senhaCliente, 10);
    
    await client.query(
      'INSERT INTO usuarios (nome, email, senha_hash, cargo, ativo, criado_em) VALUES ($1, $2, $3, $4, true, now())',
      ['Cliente Teste', 'cliente@dogueria.com', hashCliente, 'cliente']
    );
    console.log('✅ Usuário cliente criado!');
    console.log('   Email: cliente@dogueria.com');
    console.log('   Senha: cliente123\n');

    // 5. Inserir produtos
    console.log('🍔 Inserindo produtos...');
    const produtos = [
      ['Hot Dog Tradicional', 'Cachorro-quente clássico com salsicha, molho, batata palha e queijo', 'Pão, salsicha, molho de tomate, mostarda, maionese, batata palha, queijo ralado', 8.50, 'https://via.placeholder.com/300x200?text=Hot+Dog+Tradicional'],
      ['Hot Dog Especial', 'Hot dog completo com bacon, milho, ervilha e catupiry', 'Pão, salsicha, bacon, milho, ervilha, catupiry, batata palha, molhos', 12.00, 'https://via.placeholder.com/300x200?text=Hot+Dog+Especial'],
      ['Hot Dog Vegetariano', 'Versão vegetariana com salsicha de soja e legumes', 'Pão integral, salsicha de soja, cenoura, milho, ervilha, molhos vegetarianos', 10.50, 'https://via.placeholder.com/300x200?text=Hot+Dog+Vegetariano'],
      ['Hot Dog Gourmet', 'Hot dog premium com linguiça artesanal e queijos especiais', 'Pão brioche, linguiça artesanal, queijo brie, rúcula, tomate seco, molho especial', 15.00, 'https://via.placeholder.com/300x200?text=Hot+Dog+Gourmet'],
      ['Refrigerante Lata', 'Refrigerante gelado 350ml', 'Refrigerante 350ml', 4.50, 'https://via.placeholder.com/300x200?text=Refrigerante'],
      ['Suco Natural', 'Suco natural de frutas 500ml', 'Frutas frescas, água, açúcar opcional', 6.00, 'https://via.placeholder.com/300x200?text=Suco+Natural'],
      ['Batata Frita', 'Porção de batata frita crocante', 'Batata, óleo, sal', 8.00, 'https://via.placeholder.com/300x200?text=Batata+Frita'],
      ['Combo Família', '4 Hot Dogs Tradicionais + 4 Refrigerantes + Batata Frita Grande', 'Hot dogs, refrigerantes, batata frita', 55.00, 'https://via.placeholder.com/300x200?text=Combo+Familia']
    ];

    for (const produto of produtos) {
      await client.query(
        'INSERT INTO produtos (nome, descricao, ingredientes, preco, imagem_url, ativo, criado_em) VALUES ($1, $2, $3, $4, $5, true, now())',
        produto
      );
    }
    console.log(`✅ ${produtos.length} produtos inseridos com sucesso!\n`);

    console.log('🎉 Banco de dados inicializado com sucesso!\n');
    console.log('📝 Credenciais de acesso:');
    console.log('   Gerente: admin@dogueria.com / admin123');
    console.log('   Cliente: cliente@dogueria.com / cliente123\n');

  } catch (error) {
    console.error('❌ Erro ao inicializar banco de dados:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Executar
initDatabase()
  .then(() => {
    console.log('✅ Processo concluído!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('❌ Erro fatal:', error);
    process.exit(1);
  });
