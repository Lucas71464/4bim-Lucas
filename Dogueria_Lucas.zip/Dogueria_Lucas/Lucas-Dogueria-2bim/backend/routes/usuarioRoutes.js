const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');
const { isAuthenticated, isGerente } = require('../middleware/auth');

// Todas as rotas de usuário requerem autenticação de gerente
router.use(isAuthenticated);
router.use(isGerente);

// Listar todos os usuários
router.get('/', usuarioController.listarUsuarios);

// Buscar usuário por ID
router.get('/:id', usuarioController.buscarUsuario);

// Criar novo usuário
router.post('/', usuarioController.criarUsuario);

// Atualizar usuário
router.put('/:id', usuarioController.atualizarUsuario);

// Deletar usuário
router.delete('/:id', usuarioController.deletarUsuario);

module.exports = router;

