const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController-new.js');
const { isAuthenticated, isManager } = require('../middleware/auth.js');

// GET /api/usuarios - Listar usuários (apenas gerentes)
router.get('/', isAuthenticated, isManager, usuarioController.listUsers);

// GET /api/usuarios/:id - Obter usuário por ID
router.get('/:id', isAuthenticated, usuarioController.getUserById);

// POST /api/usuarios - Criar novo usuário (apenas gerentes)
router.post('/', isAuthenticated, isManager, usuarioController.createUser);

// PUT /api/usuarios/:id - Atualizar usuário (apenas gerentes)
router.put('/:id', isAuthenticated, isManager, usuarioController.updateUser);

// DELETE /api/usuarios/:id - Deletar usuário (apenas gerentes)
router.delete('/:id', isAuthenticated, isManager, usuarioController.deleteUser);

module.exports = router;
