const express = require('express');
const router = express.Router();
const relatorioController = require('../controllers/relatorioController');
const { isAuthenticated, isManager } = require('../middleware/auth');

// Todas as rotas de relatório requerem autenticação e cargo de gerente
router.use(isAuthenticated, isManager);

// GET /api/relatorios/vendas-por-mes - Relatório 1: Vendas por Mês (JSON para visualização)
router.get('/vendas-por-mes', relatorioController.vendasPorMesJSON);

// GET /api/relatorios/vendas-por-mes/imprimir - Relatório 1: Vendas por Mês (HTML para impressão)
router.get('/vendas-por-mes/imprimir', relatorioController.vendasPorMesHTML);

// GET /api/relatorios/clientes-mais-ativos - Relatório 2: Clientes Mais Ativos (JSON)
router.get('/clientes-mais-ativos', relatorioController.clientesMaisAtivosJSON);

// GET /api/relatorios/clientes-mais-ativos/imprimir - Relatório 2: Clientes Mais Ativos (HTML para impressão)
router.get('/clientes-mais-ativos/imprimir', relatorioController.clientesMaisAtivosHTML);

module.exports = router;
