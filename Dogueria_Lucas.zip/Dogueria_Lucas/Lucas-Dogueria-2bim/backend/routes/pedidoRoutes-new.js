const express = require('express');
const router = express.Router();
const pedidoController = require('../controllers/pedidoController-new.js');
const { isAuthenticated, isManager } = require('../middleware/auth.js');

// GET /api/pedidos - Listar pedidos (autenticado)
router.get('/', isAuthenticated, pedidoController.listOrders);

// GET /api/pedidos/:id - Obter pedido por ID (autenticado)
router.get('/:id', isAuthenticated, pedidoController.getOrderById);

// POST /api/pedidos - Criar novo pedido (autenticado)
router.post('/', isAuthenticated, pedidoController.createOrder);

// PUT /api/pedidos/:id/status - Atualizar status do pedido (apenas gerentes)
router.put('/:id/status', isAuthenticated, isManager, pedidoController.updateOrderStatus);

module.exports = router;
