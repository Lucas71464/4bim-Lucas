const express = require('express');
const router = express.Router();
const pedidoController = require('../controllers/pedidoController');
const { isAuthenticated, isManager } = require('../middleware/auth');

// Listar todos os pedidos (apenas gerentes)
router.get('/', isAuthenticated, isManager, pedidoController.listarPedidos);

// Obter pedido por ID (apenas autenticados)
router.get('/:id', isAuthenticated, pedidoController.obterPedido);

// Listar pedidos de um usuário específico (apenas autenticados)
router.get('/usuario/:usuario_id', isAuthenticated, pedidoController.listarPedidosPorUsuario);

// Criar novo pedido (apenas autenticados)
router.post('/', isAuthenticated, pedidoController.criarPedido);

// Atualizar pedido (apenas gerentes)
router.put('/:id', isAuthenticated, isManager, pedidoController.atualizarPedido);

// Deletar pedido (apenas gerentes)
router.delete('/:id', isAuthenticated, isManager, pedidoController.deletarPedido);

module.exports = router;


