const express = require('express');
const router = express.Router();
const produtoController = require('../controllers/produtoController-new.js');
const { isAuthenticated, isManager } = require('../middleware/auth.js');

// GET /api/produtos - Listar produtos (público)
router.get('/', produtoController.listProducts);

// GET /api/produtos/:id - Obter produto por ID (público)
router.get('/:id', produtoController.getProductById);

// POST /api/produtos - Criar produto (apenas gerentes)
router.post('/', isAuthenticated, isManager, produtoController.createProduct);

// PUT /api/produtos/:id - Atualizar produto (apenas gerentes)
router.put('/:id', isAuthenticated, isManager, produtoController.updateProduct);

// DELETE /api/produtos/:id - Deletar produto (apenas gerentes)
router.delete('/:id', isAuthenticated, isManager, produtoController.deleteProduct);

module.exports = router;
