const express = require('express');
const router = express.Router();
const perfilController = require('../controllers/perfilController');
const { isAuthenticated } = require('../middleware/auth');

// Todas as rotas de perfil requerem autenticação
router.use(isAuthenticated);

// Listar todos os perfis
router.get('/', perfilController.listarPerfis);

// Buscar perfil por ID
router.get('/:id', perfilController.buscarPerfil);

// Buscar perfil por usuario_id (relacionamento 1:1)
router.get('/usuario/:usuario_id', perfilController.buscarPerfilPorUsuario);

// Criar novo perfil
router.post('/', perfilController.criarPerfil);

// Atualizar perfil
router.put('/:id', perfilController.atualizarPerfil);

// Deletar perfil
router.delete('/:id', perfilController.deletarPerfil);

module.exports = router;

