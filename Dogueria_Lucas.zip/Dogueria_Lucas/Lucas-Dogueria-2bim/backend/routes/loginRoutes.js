const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');

// Public routes
router.post('/verificarsenha', loginController.verificarSenha);
router.post('/logout', loginController.logout);

// User verification
router.get('/verificausuario', loginController.verificaSeUsuarioEstaLogado);

// CRUD operations
router.get('/', loginController.listarUsuarios);
router.get('/:id', loginController.obterUsuario);
router.post('/', loginController.criarUsuario);
router.put('/:id', loginController.atualizarUsuario);
router.put('/:id/senha', loginController.atualizarSenha);
router.delete('/:id', loginController.deletarUsuario);

// Utility routes
router.post('/verificaremail', loginController.verificarEmail);
router.get('/email/:email', loginController.obterUsuarioPorEmail);

module.exports = router;
