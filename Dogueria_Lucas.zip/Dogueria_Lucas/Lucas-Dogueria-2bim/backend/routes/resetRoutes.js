const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { query } = require('../database');

/**
 * POST /api/reset/password
 * Resetar senha de um usuário (para desenvolvimento/debug)
 */
router.post('/password', async (req, res) => {
  try {
    const { username, newPassword } = req.body;

    if (!username || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Username e nova senha são obrigatórios'
      });
    }

    // Verificar se usuário existe
    const userResult = await query(
      'SELECT * FROM usuarios WHERE username = $1',
      [username]
    );

    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Usuário não encontrado'
      });
    }

    // Gerar hash da nova senha
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Atualizar senha
    await query(
      'UPDATE usuarios SET password = $1 WHERE username = $2',
      [hashedPassword, username]
    );

    res.json({
      success: true,
      message: `Senha do usuário "${username}" resetada com sucesso!`,
      hash: hashedPassword
    });

  } catch (error) {
    console.error('Erro ao resetar senha:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao resetar senha',
      error: error.message
    });
  }
});

/**
 * GET /api/reset/generate-hash/:password
 * Gerar hash bcrypt para uma senha (para debug)
 */
router.get('/generate-hash/:password', async (req, res) => {
  try {
    const { password } = req.params;
    const hash = await bcrypt.hash(password, 10);
    
    res.json({
      password: password,
      hash: hash,
      sql: `UPDATE usuarios SET password = '${hash}' WHERE username = 'gerente';`
    });
  } catch (error) {
    res.status(500).json({
      error: error.message
    });
  }
});

module.exports = router;

