const express = require('express');
const router = express.Router();
const clienteController = require('../controllers/clienteController');

// Listar todos os clientes
router.get('/', clienteController.listarClientes);

// Obter cliente por ID
router.get('/:id', clienteController.obterCliente);

// Criar novo cliente
router.post('/', clienteController.criarCliente);

// Atualizar cliente
router.put('/:id', clienteController.atualizarCliente);

// Deletar cliente
router.delete('/:id', clienteController.deletarCliente);

module.exports = router;


