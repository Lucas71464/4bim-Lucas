const express = require('express');
const router = express.Router();
const configController = require('../controllers/configController');
const { isAuthenticated, isManager } = require('../middleware/auth');

// Rotas para o próprio usuário (CRUD 1:1)
// GET /api/config - Obter configurações do usuário logado
router.get('/', isAuthenticated, configController.getConfiguracoes);

// POST /api/config - Salvar/Atualizar configurações do usuário logado
router.post('/', isAuthenticated, configController.salvarConfiguracoes);

// Rotas para o gerente (CRUD de terceiros)
// DELETE /api/config/:usuario_id - Deletar/Resetar configurações de um usuário (apenas gerente)
router.delete('/:usuario_id', isAuthenticated, isManager, configController.deletarConfiguracoes);

module.exports = router;
