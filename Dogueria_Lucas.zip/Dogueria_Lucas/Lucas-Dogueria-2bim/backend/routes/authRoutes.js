const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Rota de login
router.post('/login', authController.login);

// Rota de registro
router.post('/register', authController.register);

// Rota de logout
router.post('/logout', authController.logout);

// Rota para verificar sessão
router.get('/session', authController.checkSession);

module.exports = router;

