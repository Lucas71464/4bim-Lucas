const express = require('express');
const router = express.Router();
const itemPedidoController = require('../controllers/itemPedidoController');

// Listar todos os itens de pedido
router.get('/', itemPedidoController.listarItensPedido);

// Obter item de pedido por ID
router.get('/:id', itemPedidoController.obterItemPedido);

// Listar itens de um pedido específico
router.get('/pedido/:pedido_id', itemPedidoController.listarItensPorPedido);

// Criar novo item de pedido
router.post('/', itemPedidoController.criarItemPedido);

// Atualizar item de pedido
router.put('/:id', itemPedidoController.atualizarItemPedido);

// Deletar item de pedido
router.delete('/:id', itemPedidoController.deletarItemPedido);

module.exports = router;


