const express = require('express');
const router = express.Router();
const produtoController = require('../controllers/produtoController');
const { isAuthenticated, isManager } = require('../middleware/auth');

// Listar todos os produtos
router.get('/', produtoController.listarProdutos);

// Obter produto por ID
router.get('/:id', produtoController.obterProduto);

// Criar novo produto (apenas gerentes)
router.post('/', isAuthenticated, isManager, produtoController.criarProduto);

// Atualizar produto (apenas gerentes)
router.put('/:id', isAuthenticated, isManager, produtoController.atualizarProduto);

// Deletar produto (apenas gerentes)
router.delete('/:id', isAuthenticated, isManager, produtoController.deletarProduto);

module.exports = router;


