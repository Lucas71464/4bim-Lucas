const express = require('express');
const router = express.Router();
const configGerenteController = require('../controllers/configGerenteController');
const { isAuthenticated, isManager } = require('../middleware/auth');

// Todas as rotas requerem autenticação e cargo de gerente
router.use(isAuthenticated, isManager);

// GET /api/config-gerente - Obter configurações do gerente logado
router.get('/', configGerenteController.getConfiguracoes);

// POST /api/config-gerente - Salvar/Atualizar configurações do gerente logado
router.post('/', configGerenteController.salvarConfiguracoes);

// DELETE /api/config-gerente - Deletar/Resetar configurações do gerente logado
router.delete('/', configGerenteController.deletarConfiguracoes);

module.exports = router;
