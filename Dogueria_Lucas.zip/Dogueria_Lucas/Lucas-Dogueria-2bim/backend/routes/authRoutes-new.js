const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController-new.js');
const { isAuthenticated } = require('../middleware/auth.js');

// POST /api/register - Registrar novo usuário
router.post('/register', loginController.register);

// POST /api/login - Fazer login
router.post('/login', loginController.login);

// POST /api/logout - Fazer logout
router.post('/logout', loginController.logout);

// GET /api/me - Obter dados do usuário logado
router.get('/me', isAuthenticated, loginController.getCurrentUser);

module.exports = router;
