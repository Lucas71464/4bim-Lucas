// Middleware para verificar se o usuário está autenticado
const isAuthenticated = (req, res, next) => {
  if (req.session && req.session.usuario && req.session.usuario.id) {
    return next();
  }
  return res.status(401).json({ status: 'erro', mensagem: 'Não autenticado. Faça login.' });
};

// Middleware para verificar se o usuário é gerente
const isManager = (req, res, next) => {
  if (req.session && req.session.usuario && req.session.usuario.cargo === 'gerente') {
    return next();
  }
  return res.status(403).json({ status: 'erro', mensagem: 'Acesso negado. Apenas gerentes.' });
};

// Alias para compatibilidade
const isGerente = isManager;

// Middleware para verificar se o usuário é cliente
const isClient = (req, res, next) => {
  if (req.session && req.session.usuario && req.session.usuario.cargo === 'cliente') {
    return next();
  }
  return res.status(403).json({ status: 'erro', mensagem: 'Acesso negado. Apenas clientes.' });
};

// Alias para compatibilidade
const isCliente = isClient;

// Middleware para verificar se o usuário é gerente ou está acessando seus próprios dados
const isManagerOrSelf = (req, res, next) => {
  const usuarioId = parseInt(req.params.id);
  const usuarioLogadoId = req.session?.usuario?.id;
  const cargo = req.session?.usuario?.cargo;
  
  if (cargo === 'gerente' || usuarioId === usuarioLogadoId) {
    return next();
  }
  
  return res.status(403).json({ status: 'erro', mensagem: 'Acesso negado.' });
};

module.exports = {
  isAuthenticated,
  isManager,
  isGerente,
  isClient,
  isCliente,
  isManagerOrSelf
};

