// crud-pedidos.js

let pedidoAtualId = null;

// Funções auxiliares de formatação (copiadas de pedidos-cliente.js)
function formatarPreco(preco) {
    return parseFloat(preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function formatarData(data) {
    return new Date(data).toLocaleString('pt-BR', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function getStatusNome(status) {
    const statusMap = {
        'pendente': 'Pendente',
        'preparacao': 'Em Preparação',
        'transporte': 'Em Transporte',
        'entregue': 'Entregue',
        'cancelado': 'Cancelado'
    };
    return statusMap[status] || status;
}

function getStatusCor(status) {
    const statusCor = {
        'pendente': '#f39c12', // Laranja
        'preparacao': '#3498db', // Azul
        'transporte': '#2ecc71', // Verde
        'entregue': '#27ae60', // Verde Escuro
        'cancelado': '#e74c3c' // Vermelho
    };
    return statusCor[status] || '#95a5a6'; // Cinza
}

// Função auxiliar para mostrar mensagens
function mostrarMensagem(tipo, mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.classList.add('hidden');

    if (tipo === 'erro') {
        errorMsg.textContent = '✗ ' + mensagem;
        errorMsg.classList.remove('hidden');
    } else if (tipo === 'sucesso') {
        successMsg.textContent = '✓ ' + mensagem;
        successMsg.classList.remove('hidden');
    }
    
    setTimeout(() => {
        errorMsg.classList.add('hidden');
        successMsg.classList.add('hidden');
    }, 5000);
}

// Verificar se usuário é gerente ao carregar a página
async function verificarPermissao() {
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = '../login.html';
            return false;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok' || data.usuario.cargo !== 'gerente') {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = '../index.html';
            return false;
        }

        return true;
    } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        alert('Erro ao verificar permissões');
        window.location.href = '../index.html';
        return false;
    }
}

// Carregar lista de pedidos
async function carregarPedidos() {
    try {
        const response = await fetch('/api/pedidos', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao carregar pedidos');
        }

        const pedidos = await response.json();
        const tbody = document.getElementById('pedidosTableBody');

        if (pedidos.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #666;">Nenhum pedido encontrado</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        pedidos.forEach(pedido => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid #eee';

            const statusNome = getStatusNome(pedido.status);
            const statusCor = getStatusCor(pedido.status);

            tr.innerHTML = `
                <td style="padding: 1rem;">${pedido.id}</td>
                <td style="padding: 1rem;">${pedido.usuario_nome} (${pedido.usuario_email})</td>
                <td style="padding: 1rem;">${formatarData(pedido.criado_em)}</td>
                <td style="padding: 1rem; text-align: center; font-weight: bold; color: #27ae60;">${formatarPreco(pedido.valor_total)}</td>
                <td style="padding: 1rem; text-align: center;">
                    <span style="background: ${statusCor}; color: white; padding: 0.25rem 0.75rem; border-radius: 4px; font-weight: bold;">${statusNome}</span>
                </td>
                <td style="padding: 1rem; text-align: center;">
                    <button onclick="abrirModal(${pedido.id})" class="btn" style="background: #3498db; padding: 0.5rem 1rem; margin-right: 0.5rem;">🔍 Detalhes</button>
                    <button onclick="deletarPedido(${pedido.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">🗑️ Deletar</button>
                </td>
            `;

            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar pedidos:', error);
        mostrarMensagem('erro', 'Erro ao carregar pedidos: ' + error.message);
    }
}

// Abrir modal de detalhes e edição
async function abrirModal(id) {
    try {
        const response = await fetch(`/api/pedidos/${id}`, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao buscar detalhes do pedido');
        }

        const pedido = await response.json();
        pedidoAtualId = id;

        document.getElementById('modalPedidoId').textContent = `#${id}`;
        document.getElementById('novoStatus').value = pedido.status;

        let itensHtml = pedido.itens.map(item => `
            <li>${item.quantidade}x ${item.produto_nome} (${formatarPreco(item.preco_unit)})</li>
        `).join('');

        const modalContent = document.getElementById('modalContent');
        modalContent.innerHTML = `
            <p><strong>Cliente:</strong> ${pedido.usuario_nome} (${pedido.usuario_email})</p>
            <p><strong>Data:</strong> ${formatarData(pedido.criado_em)}</p>
            <p><strong>Total:</strong> <span style="font-weight: bold; color: #27ae60;">${formatarPreco(pedido.valor_total)}</span></p>
            <p><strong>Pagamento:</strong> ${pedido.metodo_pagamento}</p>
            ${pedido.metodo_pagamento === 'dinheiro' && pedido.troco_para ? `<p><strong>Troco para:</strong> ${formatarPreco(pedido.troco_para)}</p>` : ''}
            
            <h4 style="margin-top: 1rem;">Itens do Pedido:</h4>
            <ul style="list-style: disc; padding-left: 20px;">
                ${itensHtml}
            </ul>
        `;

        document.getElementById('pedidoModal').style.display = 'block';

    } catch (error) {
        console.error('Erro ao abrir modal:', error);
        mostrarMensagem('erro', 'Erro ao carregar detalhes do pedido: ' + error.message);
    }
}

// Fechar modal
function fecharModal() {
    document.getElementById('pedidoModal').style.display = 'none';
    pedidoAtualId = null;
}

// Manipular atualização de status
document.getElementById('statusForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!pedidoAtualId) return;

    const novoStatus = document.getElementById('novoStatus').value;

    try {
        const response = await fetch(`/api/pedidos/${pedidoAtualId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ status: novoStatus })
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao atualizar status');
        }

        mostrarMensagem('sucesso', `Status do Pedido #${pedidoAtualId} atualizado para ${getStatusNome(novoStatus)}!`);
        fecharModal();
        carregarPedidos(); // Recarrega a lista
    } catch (error) {
        console.error('Erro ao atualizar status:', error);
        mostrarMensagem('erro', error.message || 'Erro ao atualizar status');
    }
});

// Deletar pedido
async function deletarPedido(id) {
    if (!confirm(`Tem certeza que deseja deletar o Pedido #${id}? Esta ação é irreversível.`)) {
        return;
    }

    try {
        const response = await fetch(`/api/pedidos/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao deletar pedido');
        }

        mostrarMensagem('sucesso', `Pedido #${id} deletado com sucesso!`);
        carregarPedidos();
    } catch (error) {
        console.error('Erro ao deletar pedido:', error);
        mostrarMensagem('erro', 'Erro ao deletar pedido: ' + error.message);
    }
}

// Event listeners para fechar modal
document.getElementById('closeModal').onclick = fecharModal;
window.onclick = function(event) {
    if (event.target == document.getElementById('pedidoModal')) {
        fecharModal();
    }
}

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarPedidos();
        }
    });
} else {
    (async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarPedidos();
        }
    })();
}
