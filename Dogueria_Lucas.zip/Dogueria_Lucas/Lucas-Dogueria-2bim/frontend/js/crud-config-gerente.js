// crud-config-gerente.js

// Função auxiliar para mostrar mensagens
function mostrarMensagem(tipo, mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.classList.add('hidden');

    if (tipo === 'erro') {
        errorMsg.textContent = '✗ ' + mensagem;
        errorMsg.classList.remove('hidden');
    } else if (tipo === 'sucesso') {
        successMsg.textContent = '✓ ' + mensagem;
        successMsg.classList.remove('hidden');
    }
    
    setTimeout(() => {
        errorMsg.classList.add('hidden');
        successMsg.classList.add('hidden');
    }, 5000);
}

// Verificar se usuário é gerente ao carregar a página
async function verificarPermissao() {
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = '../login.html';
            return false;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok' || data.usuario.cargo !== 'gerente') {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = '../index.html';
            return false;
        }

        return true;
    } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        alert('Erro ao verificar permissões');
        window.location.href = '../index.html';
        return false;
    }
}

// Carregar configurações atuais
async function carregarConfiguracoes() {
    try {
        const response = await fetch('/api/config-gerente', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao carregar configurações gerenciais');
        }

        const config = await response.json();
        
        document.getElementById('margem_lucro_padrao').value = parseFloat(config.margem_lucro_padrao || 30.00).toFixed(2);
        document.getElementById('limite_desconto_maximo').value = parseFloat(config.limite_desconto_maximo || 10.00).toFixed(2);

    } catch (error) {
        console.error('Erro ao carregar configurações gerenciais:', error);
        mostrarMensagem('erro', 'Erro ao carregar configurações: ' + error.message);
    }
}

// Manipular envio do formulário
document.getElementById('configGerenteForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const margem_lucro_padrao = parseFloat(document.getElementById('margem_lucro_padrao').value);
    const limite_desconto_maximo = parseFloat(document.getElementById('limite_desconto_maximo').value);

    const dados = {
        margem_lucro_padrao,
        limite_desconto_maximo
    };

    try {
        const response = await fetch('/api/config-gerente', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao salvar configurações');
        }

        mostrarMensagem('sucesso', 'Configurações gerenciais salvas com sucesso!');
        carregarConfiguracoes(); // Recarrega para garantir que os valores formatados estejam corretos
    } catch (error) {
        console.error('Erro ao salvar configurações:', error);
        mostrarMensagem('erro', error.message || 'Erro ao salvar configurações');
    }
});

// Manipular botão de reset
document.getElementById('resetBtn').addEventListener('click', async () => {
    if (!confirm('Tem certeza que deseja resetar as configurações gerenciais para o padrão?')) {
        return;
    }

    try {
        const response = await fetch('/api/config-gerente', {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao resetar configurações');
        }

        mostrarMensagem('sucesso', 'Configurações resetadas para o padrão com sucesso!');
        carregarConfiguracoes(); // Recarrega para mostrar os valores padrão
    } catch (error) {
        console.error('Erro ao resetar configurações:', error);
        mostrarMensagem('erro', error.message || 'Erro ao resetar configurações');
    }
});

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarConfiguracoes();
        }
    });
} else {
    (async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarConfiguracoes();
        }
    })();
}
