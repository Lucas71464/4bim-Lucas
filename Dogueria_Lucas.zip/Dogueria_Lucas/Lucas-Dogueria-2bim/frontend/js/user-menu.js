// user-menu.js - Gerencia menu dinâmico baseado no usuário logado

async function verificarUsuarioLogado() {
    try {
        const response = await fetch('/api/me', { method: 'GET', credentials: 'include' });
        if (response.ok) {
            const data = await response.json();
            if (data && data.status === 'ok' && data.usuario) {
                return { 
                    logado: true, 
                    nome: data.usuario.nome,
                    cargo: data.usuario.cargo,
                    avatar_url: data.usuario.avatar_url
                };
            }
        }

        return { logado: false };
    } catch (error) {
        console.error('Erro ao verificar usuário:', error);
        return { logado: false };
    }
}

async function inicializarMenu() {
    const usuario = await verificarUsuarioLogado();
    const loginBtn = document.getElementById('loginBtn');
    const headerNav = document.getElementById('headerNav');
    
    if (!loginBtn) return;
    
    if (usuario.logado) {
        // Usuário está logado
        const displayName = usuario.avatar_url 
            ? `<img src="${usuario.avatar_url}" alt="Avatar" style="width: 32px; height: 32px; border-radius: 50%; vertical-align: middle; margin-right: 0.5rem;">${usuario.nome}`
            : `👤 ${usuario.nome}`;
        
        loginBtn.innerHTML = displayName;
        loginBtn.href = '#';
        loginBtn.style.cursor = 'pointer';
        loginBtn.onclick = (e) => {
            e.preventDefault();
            const menu = document.getElementById('userDropdown');
            if (menu) {
                menu.style.display = menu.style.display === 'none' || menu.style.display === '' ? 'block' : 'none';
            }
        };
        
        // Criar dropdown se não existir
        if (!document.getElementById('userDropdown')) {
            const dropdown = document.createElement('div');
            dropdown.id = 'userDropdown';
            dropdown.style.cssText = 'display: none; position: absolute; top: 60px; right: 20px; background: white; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; min-width: 200px;';
            
            let menuHtml = '';
            
            // Mostrar opções de CRUD apenas para gerentes
            if (usuario.cargo === 'gerente') {
                menuHtml += `
                    <div style="padding: 0.5rem 1rem; background: #3498db; color: white; font-weight: bold; border-radius: 8px 8px 0 0;">
                        🔧 Painel de Gerente
                    </div>
                    <a href="../crud-usuarios/index.html" style="display: block; padding: 0.75rem 1rem; color: #333; text-decoration: none; border-bottom: 1px solid #eee; transition: background 0.2s;" onmouseover="this.style.background='#f8f9fa'" onmouseout="this.style.background='white'">👥 Gerenciar Usuários</a>
                    <a href="../crud-produtos/index.html" style="display: block; padding: 0.75rem 1rem; color: #333; text-decoration: none; border-bottom: 1px solid #eee; transition: background 0.2s;" onmouseover="this.style.background='#f8f9fa'" onmouseout="this.style.background='white'">🍔 Gerenciar Produtos</a>
                    <a href="../crud-config-gerente/index.html" style="display: block; padding: 0.75rem 1rem; color: #333; text-decoration: none; border-bottom: 1px solid #eee; transition: background 0.2s;" onmouseover="this.style.background='#f8f9fa'" onmouseout="this.style.background='white'">⚙️ Config. Gerenciais</a>
                    <a href="../crud-pedidos/index.html" style="display: block; padding: 0.75rem 1rem; color: #333; text-decoration: none; border-bottom: 1px solid #eee; transition: background 0.2s;" onmouseover="this.style.background='#f8f9fa'" onmouseout="this.style.background='white'">🧾 Gerenciar Pedidos</a>
                    <a href="../crud-relatorios/index.html" style="display: block; padding: 0.75rem 1rem; color: #333; text-decoration: none; border-bottom: 1px solid #eee; transition: background 0.2s;" onmouseover="this.style.background='#f8f9fa'" onmouseout="this.style.background='white'">📊 Relatórios</a>
                    <div style="height: 1px; background: #ddd; margin: 0.5rem 0;"></div>
                `;
            }
            
            menuHtml += `
                <a href="#" onclick="logout(); return false;" style="display: block; padding: 0.75rem 1rem; color: #e74c3c; text-decoration: none; font-weight: bold; transition: background 0.2s;" onmouseover="this.style.background='#fee'" onmouseout="this.style.background='white'">🚪 Sair</a>
            `;
            
            dropdown.innerHTML = menuHtml;
            document.body.appendChild(dropdown);
            
            // Fechar dropdown ao clicar fora
            document.addEventListener('click', (e) => {
                if (!loginBtn.contains(e.target) && !dropdown.contains(e.target)) {
                    dropdown.style.display = 'none';
                }
            });
        }
    } else {
        // Usuário não está logado
        loginBtn.textContent = 'Login';
        loginBtn.href = 'login.html';
        loginBtn.onclick = null;
        loginBtn.style.cursor = 'pointer';
        
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) dropdown.remove();
    }
}

async function logout() {
    try {
        await fetch('/api/logout', {
            method: 'POST',
            credentials: 'include'
        });
        
        // Limpar dropdown
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) dropdown.remove();
        
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Erro ao fazer logout:', error);
        alert('Erro ao fazer logout');
    }
}

// Inicializar quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializarMenu);
} else {
    inicializarMenu();
}
