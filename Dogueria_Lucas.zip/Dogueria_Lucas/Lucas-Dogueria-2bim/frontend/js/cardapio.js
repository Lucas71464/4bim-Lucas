// cardapio.js - Carrega e exibe produtos

async function carregarProdutos() {
    try {
        const response = await fetch('/api/produtos', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            const body = await response.text().catch(() => null);
            throw new Error(`Erro ao carregar produtos (status ${response.status}) ${body ? '- ' + body : ''}`);
        }

        const data = await response.json();
        const produtos = Array.isArray(data) ? data : (data.produtos || []);
        const container = document.getElementById('produtosContainer');

        if (!produtos || produtos.length === 0) {
            container.innerHTML = '<p>Nenhum produto disponível</p>';
            return;
        }

        container.innerHTML = '';
        produtos.forEach(prod => {
            const card = document.createElement('div');
            card.style.cssText = 'background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: transform 0.3s, box-shadow 0.3s; display: flex; flex-direction: column;';
            card.onmouseover = () => {
                card.style.transform = 'translateY(-5px)';
                card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
            };
            card.onmouseout = () => {
                card.style.transform = 'translateY(0)';
                card.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
            };

            // Imagem do produto (se houver)
            if (prod.imagem_url) {
                const img = document.createElement('img');
                img.src = prod.imagem_url;
                img.alt = prod.nome;
                img.style.cssText = 'width: 100%; height: 180px; object-fit: cover; border-radius: 6px; margin-bottom: 1rem;';
                card.appendChild(img);
            }

            const title = document.createElement('h3');
            title.textContent = prod.nome || 'Produto';
            title.style.cssText = 'margin: 0 0 0.5rem 0; color: #333;';

            const desc = document.createElement('p');
            desc.textContent = prod.descricao || 'Sem descrição';
            desc.style.cssText = 'margin: 0 0 0.5rem 0; color: #666; font-size: 0.9rem;';

            // Mostrar ingredientes
            if (prod.ingredientes) {
                const ingredientes = document.createElement('p');
                ingredientes.innerHTML = `<strong>Ingredientes:</strong> ${prod.ingredientes}`;
                ingredientes.style.cssText = 'margin: 0 0 0.5rem 0; color: #555; font-size: 0.85rem; line-height: 1.4;';
                card.appendChild(title);
                card.appendChild(desc);
                card.appendChild(ingredientes);
            } else {
                card.appendChild(title);
                card.appendChild(desc);
            }

            const price = document.createElement('p');
            price.innerHTML = `<strong style="color: #27ae60; font-size: 1.3rem;">R$ ${parseFloat(prod.preco || 0).toFixed(2)}</strong>`;
            price.style.cssText = 'margin: 0.5rem 0 1rem 0;';

            const btn = document.createElement('button');
            btn.className = 'btn btn-primary';
            btn.textContent = '🛒 Adicionar ao Carrinho';
            btn.style.cssText = 'margin-top: auto;';
            btn.addEventListener('click', () => adicionarAoCarrinho(prod.id, prod.nome, prod.preco));

            card.appendChild(price);
            card.appendChild(btn);

            container.appendChild(card);
        });
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        const container = document.getElementById('produtosContainer');
        if (container) container.innerHTML = '<p style="color: red;">Erro ao carregar produtos</p>';
    }
}

function adicionarAoCarrinho(id, nome, preco) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    // Verificar se o produto já está no carrinho
    const itemExistente = carrinho.find(item => item.id === id);
    
    if (itemExistente) {
        itemExistente.quantidade += 1;
    } else {
        carrinho.push({ id, nome, preco, quantidade: 1 });
    }
    
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    
    // Feedback visual
    alert(`✓ ${nome} adicionado ao carrinho!`);
}

// Carregar produtos ao inicializar
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarProdutos);
} else {
    carregarProdutos();
}
