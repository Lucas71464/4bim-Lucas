// crud-config.js

// Função auxiliar para mostrar mensagens
function mostrarMensagem(tipo, mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.classList.add('hidden');

    if (tipo === 'erro') {
        errorMsg.textContent = '✗ ' + mensagem;
        errorMsg.classList.remove('hidden');
    } else if (tipo === 'sucesso') {
        successMsg.textContent = '✓ ' + mensagem;
        successMsg.classList.remove('hidden');
    }
    
    setTimeout(() => {
        errorMsg.classList.add('hidden');
        successMsg.classList.add('hidden');
    }, 5000);
}

// Carregar configurações atuais
async function carregarConfiguracoes() {
    try {
        const response = await fetch('/api/config', {
            method: 'GET',
            credentials: 'include'
        });

        if (response.status === 401) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = '../login.html';
            return;
        }

        if (!response.ok) {
            throw new Error('Erro ao carregar configurações');
        }

        const config = await response.json();
        
        document.getElementById('tema_preferido').value = config.tema_preferido || 'claro';
        document.getElementById('receber_notificacoes').checked = config.receber_notificacoes === true;

    } catch (error) {
        console.error('Erro ao carregar configurações:', error);
        mostrarMensagem('erro', 'Erro ao carregar configurações: ' + error.message);
    }
}

// Manipular envio do formulário
document.getElementById('configForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const tema_preferido = document.getElementById('tema_preferido').value;
    const receber_notificacoes = document.getElementById('receber_notificacoes').checked;

    const dados = {
        tema_preferido,
        receber_notificacoes
    };

    try {
        const response = await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(dados)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao salvar configurações');
        }

        mostrarMensagem('sucesso', 'Configurações salvas com sucesso!');
    } catch (error) {
        console.error('Erro ao salvar configurações:', error);
        mostrarMensagem('erro', error.message || 'Erro ao salvar configurações');
    }
});

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarConfiguracoes);
} else {
    carregarConfiguracoes();
}
