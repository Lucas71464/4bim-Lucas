// carrinho.js

function carregarCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    const container = document.getElementById('carrinhoContainer');
    
    if (carrinho.length === 0) {
        container.innerHTML = '<p style="text-align: center; padding: 2rem; color: #666;">Seu carrinho está vazio</p>';
        return;
    }
    
    let html = '<table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">';
    html += '<thead><tr style="background: #3498db; color: white;">';
    html += '<th style="padding: 1rem; text-align: left;">Produto</th>';
    html += '<th style="padding: 1rem; text-align: center;">Preço Unit.</th>';
    html += '<th style="padding: 1rem; text-align: center;">Quantidade</th>';
    html += '<th style="padding: 1rem; text-align: right;">Subtotal</th>';
    html += '<th style="padding: 1rem; text-align: center;">Ações</th>';
    html += '</tr></thead><tbody>';
    
    let total = 0;
    
    carrinho.forEach((item, index) => {
        const subtotal = item.preco * item.quantidade;
        total += subtotal;
        html += `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 1rem;">${item.nome}</td>
                <td style="padding: 1rem; text-align: center;">R$ ${parseFloat(item.preco).toFixed(2)}</td>
                <td style="padding: 1rem; text-align: center;">
                    <input type="number" value="${item.quantidade}" min="1" onchange="atualizarQtd(${index}, this.value)" style="width: 60px; padding: 0.3rem; text-align: center; border: 1px solid #ddd; border-radius: 4px;">
                </td>
                <td style="padding: 1rem; text-align: right; font-weight: bold;">R$ ${subtotal.toFixed(2)}</td>
                <td style="padding: 1rem; text-align: center;">
                    <button onclick="removerDoCarrinho(${index})" class="btn btn-danger" style="padding: 0.5rem 1rem;">🗑️ Remover</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    html += `<div style="margin-top: 2rem; padding: 1.5rem; background: white; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">`;
    html += `<h3 style="text-align: right; margin: 0; font-size: 1.5rem; color: #27ae60;">Total: R$ ${total.toFixed(2)}</h3>`;
    html += `</div>`;
    
    container.innerHTML = html;
}

function atualizarQtd(index, novaQtd) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    const qtd = parseInt(novaQtd);
    
    if (qtd <= 0) {
        removerDoCarrinho(index);
        return;
    }
    
    carrinho[index].quantidade = qtd;
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}

function removerDoCarrinho(index) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}

function limparCarrinho() {
    if (confirm('Tem certeza que deseja limpar o carrinho?')) {
        localStorage.removeItem('carrinho');
        carregarCarrinho();
    }
}

async function finalizarCompra() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    if (carrinho.length === 0) {
        alert('Carrinho vazio!');
        return;
    }
    
    // Verificar se usuário está logado usando rota /api/me
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa fazer login para finalizar a compra');
            window.location.href = 'login.html';
            return;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok') {
            alert('Você precisa fazer login para finalizar a compra');
            window.location.href = 'login.html';
            return;
        }

        // Redirecionar para página de pagamento
        window.location.href = 'pagamento.html';
        
    } catch (error) {
        console.error('Erro ao verificar login:', error);
        alert('Erro ao processar. Tente novamente.');
    }
}

// Carregar ao inicializar
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarCarrinho);
} else {
    carregarCarrinho();
}
