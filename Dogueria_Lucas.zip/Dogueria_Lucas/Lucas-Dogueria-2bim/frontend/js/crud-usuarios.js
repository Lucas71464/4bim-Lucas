// crud-usuarios.js

let editandoId = null;

// Verificar se usuário é gerente ao carregar a página
async function verificarPermissao() {
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = 'login.html';
            return false;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok' || data.usuario.cargo !== 'gerente') {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = 'index.html';
            return false;
        }

        return true;
    } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        alert('Erro ao verificar permissões');
        window.location.href = 'index.html';
        return false;
    }
}

async function carregarUsuarios() {
    try {
        const response = await fetch('/api/usuarios', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao carregar usuários');
        }

        const usuarios = await response.json();
        const tbody = document.getElementById('usuariosTableBody');

        if (usuarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #666;">Nenhum usuário encontrado</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        usuarios.forEach(usuario => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid #eee';

            const statusBadge = usuario.ativo 
                ? '<span style="background: #27ae60; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Ativo</span>'
                : '<span style="background: #e74c3c; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Inativo</span>';

            const cargoBadge = usuario.cargo === 'gerente'
                ? '<span style="background: #3498db; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Gerente</span>'
                : '<span style="background: #95a5a6; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Cliente</span>';

            tr.innerHTML = `
                <td style="padding: 1rem;">${usuario.id}</td>
                <td style="padding: 1rem;">${usuario.nome}</td>
                <td style="padding: 1rem;">${usuario.email}</td>
                <td style="padding: 1rem; text-align: center;">${cargoBadge}</td>
                <td style="padding: 1rem; text-align: center;">${statusBadge}</td>
                <td style="padding: 1rem; text-align: center;">
                    <button onclick="editarUsuario(${usuario.id})" class="btn" style="background: #f39c12; padding: 0.5rem 1rem; margin-right: 0.5rem;">✏️ Editar</button>
                    <button onclick="deletarUsuario(${usuario.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">🗑️ Deletar</button>
                </td>
            `;

            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        mostrarErro('Erro ao carregar usuários');
    }
}

async function editarUsuario(id) {
    try {
        const response = await fetch(`/api/usuarios/${id}`, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao buscar usuário');
        }

        const usuario = await response.json();

        editandoId = id;
        document.getElementById('formTitle').textContent = 'Editar Usuário';
        document.getElementById('usuarioId').value = id;
        document.getElementById('nome').value = usuario.nome;
        document.getElementById('email').value = usuario.email;
        document.getElementById('senha').value = '';
        document.getElementById('senha').placeholder = 'Deixe em branco para manter a senha atual';
        document.getElementById('cargo').value = usuario.cargo;
        document.getElementById('avatar_url').value = usuario.avatar_url || '';
        document.getElementById('ativo').value = usuario.ativo ? 'true' : 'false';

        // Scroll para o formulário
        document.getElementById('usuarioForm').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Erro ao editar usuário:', error);
        mostrarErro('Erro ao carregar dados do usuário');
    }
}

async function deletarUsuario(id) {
    if (!confirm('Tem certeza que deseja deletar este usuário?')) {
        return;
    }

    try {
        const response = await fetch(`/api/usuarios/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao deletar usuário');
        }

        mostrarSucesso('Usuário deletado com sucesso!');
        carregarUsuarios();
    } catch (error) {
        console.error('Erro ao deletar usuário:', error);
        mostrarErro('Erro ao deletar usuário');
    }
}

function cancelarEdicao() {
    editandoId = null;
    document.getElementById('formTitle').textContent = 'Adicionar Novo Usuário';
    document.getElementById('usuarioForm').reset();
    document.getElementById('usuarioId').value = '';
    document.getElementById('senha').placeholder = 'Mínimo 6 caracteres';
}

function mostrarErro(mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    successMsg.classList.add('hidden');
    errorMsg.textContent = '✗ ' + mensagem;
    errorMsg.classList.remove('hidden');
    
    setTimeout(() => errorMsg.classList.add('hidden'), 5000);
}

function mostrarSucesso(mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.textContent = '✓ ' + mensagem;
    successMsg.classList.remove('hidden');
    
    setTimeout(() => successMsg.classList.add('hidden'), 5000);
}

// Manipular envio do formulário
document.getElementById('usuarioForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const senha = document.getElementById('senha').value;
    const cargo = document.getElementById('cargo').value;
    const avatar_url = document.getElementById('avatar_url').value.trim();
    const ativo = document.getElementById('ativo').value === 'true';

    if (!nome || !email) {
        mostrarErro('Nome e email são obrigatórios');
        return;
    }

    if (!editandoId && (!senha || senha.length < 6)) {
        mostrarErro('Senha deve ter no mínimo 6 caracteres');
        return;
    }

    const dados = {
        nome,
        email,
        cargo,
        avatar_url: avatar_url || null,
        ativo
    };

    if (senha && senha.length >= 6) {
        dados.senha = senha;
    }

    try {
        let response;
        
        if (editandoId) {
            // Atualizar usuário existente
            response = await fetch(`/api/usuarios/${editandoId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(dados)
            });
        } else {
            // Criar novo usuário
            if (!senha) {
                mostrarErro('Senha é obrigatória para novos usuários');
                return;
            }
            
            response = await fetch('/api/usuarios', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(dados)
            });
        }

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao salvar usuário');
        }

        mostrarSucesso(editandoId ? 'Usuário atualizado com sucesso!' : 'Usuário criado com sucesso!');
        cancelarEdicao();
        carregarUsuarios();
    } catch (error) {
        console.error('Erro ao salvar usuário:', error);
        mostrarErro(error.message || 'Erro ao salvar usuário');
    }
});

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarUsuarios();
        }
    });
} else {
    (async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarUsuarios();
        }
    })();
}
