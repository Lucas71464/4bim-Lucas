// crud-clientes.js - CRUD para clientes

const API_URL = 'http://localhost:3000/api/clientes';
let currentClienteId = null;
let operacao = null;

const form = document.getElementById('clienteForm');
const searchId = document.getElementById('searchId');
const btnBuscar = document.getElementById('btnBuscar');
const btnIncluir = document.getElementById('btnIncluir');
const btnAlterar = document.getElementById('btnAlterar');
const btnExcluir = document.getElementById('btnExcluir');
const btnCancelar = document.getElementById('btnCancelar');
const btnSalvar = document.getElementById('btnSalvar');
const clientesTableBody = document.getElementById('clientesTableBody');
const messageContainer = document.getElementById('messageContainer');

document.addEventListener('DOMContentLoaded', () => {
    carregarClientes();
    btnBuscar.addEventListener('click', buscarCliente);
    btnIncluir.addEventListener('click', incluirCliente);
    btnAlterar.addEventListener('click', alterarCliente);
    btnExcluir.addEventListener('click', excluirCliente);
    btnCancelar.addEventListener('click', cancelarOperacao);
    btnSalvar.addEventListener('click', salvarOperacao);
});

function mostrarMensagem(texto, tipo = 'info') {
    const class_tipo = tipo === 'success' ? 'success-message' : tipo === 'error' ? 'error-message' : 'info-message';
    messageContainer.innerHTML = `<div class="${class_tipo}">${texto}</div>`;
    setTimeout(() => { messageContainer.innerHTML = ''; }, 3000);
}

function bloquearCampos(bloquear) {
    const inputs = document.querySelectorAll('#clienteForm input:not(#searchId)');
    inputs.forEach(input => { input.disabled = !bloquear; });
}

function limparFormulario() {
    form.reset();
}

function mostrarBotoes(btBuscar, btIncluir, btAlterar, btExcluir, btSalvar, btCancelar) {
    btnBuscar.style.display = btBuscar ? 'inline-block' : 'none';
    btnIncluir.style.display = btIncluir ? 'inline-block' : 'none';
    btnAlterar.style.display = btAlterar ? 'inline-block' : 'none';
    btnExcluir.style.display = btExcluir ? 'inline-block' : 'none';
    btnSalvar.style.display = btSalvar ? 'inline-block' : 'none';
    btnCancelar.style.display = btCancelar ? 'inline-block' : 'none';
}

async function buscarCliente() {
    const id = searchId.value.trim();
    if (!id) { mostrarMensagem('Digite um ID', 'warning'); return; }
    
    try {
        const response = await fetch(`${API_URL}/${id}`, { credentials: 'include' });
        if (!response.ok) throw new Error('Cliente não encontrado');
        
        const cliente = await response.json();
        document.getElementById('nome').value = cliente.nome || '';
        document.getElementById('telefone').value = cliente.telefone || '';
        document.getElementById('email').value = cliente.email || '';
        document.getElementById('endereco').value = cliente.endereco || '';
        currentClienteId = cliente.id;
        
        mostrarBotoes(true, false, true, true, false, false);
        mostrarMensagem('Cliente encontrado!', 'success');
    } catch (error) {
        mostrarMensagem('Cliente não encontrado', 'error');
        limparFormulario();
        mostrarBotoes(true, true, false, false, false, false);
        bloquearCampos(false);
    }
}

async function incluirCliente() {
    limparFormulario();
    bloquearCampos(true);
    mostrarBotoes(false, false, false, false, true, true);
    operacao = 'incluir';
    document.getElementById('nome').focus();
}

async function alterarCliente() {
    bloquearCampos(true);
    mostrarBotoes(false, false, false, false, true, true);
    operacao = 'alterar';
    document.getElementById('nome').focus();
}

async function excluirCliente() {
    operacao = 'excluir';
    mostrarBotoes(false, false, false, false, true, true);
}

async function salvarOperacao() {
    const cliente = {
        nome: document.getElementById('nome').value,
        telefone: document.getElementById('telefone').value,
        email: document.getElementById('email').value,
        endereco: document.getElementById('endereco').value
    };
    
    let url = API_URL;
    let method = 'POST';
    
    if (operacao === 'alterar') {
        url = `${API_URL}/${currentClienteId}`;
        method = 'PUT';
    } else if (operacao === 'excluir') {
        url = `${API_URL}/${currentClienteId}`;
        method = 'DELETE';
    }
    
    try {
        const response = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: method === 'DELETE' ? undefined : JSON.stringify(cliente)
        });
        
        if (!response.ok) throw new Error('Erro na operação');
        
        mostrarMensagem(`Cliente ${operacao === 'excluir' ? 'excluído' : 'salvo'} com sucesso!`, 'success');
        cancelarOperacao();
        carregarClientes();
    } catch (error) {
        mostrarMensagem('Erro: ' + error.message, 'error');
    }
}

function cancelarOperacao() {
    limparFormulario();
    currentClienteId = null;
    operacao = null;
    mostrarBotoes(true, false, false, false, false, false);
    bloquearCampos(false);
    searchId.value = '';
    searchId.focus();
}

async function carregarClientes() {
    try {
        const response = await fetch(API_URL, { credentials: 'include' });
        if (!response.ok) throw new Error('Erro ao carregar');
        
        const clientes = await response.json();
        clientesTableBody.innerHTML = '';
        clientes.forEach(cliente => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${cliente.id}</td>
                <td>${cliente.nome}</td>
                <td>${cliente.telefone || '-'}</td>
                <td>${cliente.email || '-'}</td>
                <td>${cliente.endereco || '-'}</td>
            `;
            clientesTableBody.appendChild(tr);
        });
    } catch (error) {
        mostrarMensagem('Erro ao carregar clientes', 'error');
    }
}
