// crud-produtos.js

let editandoId = null;

// Verificar se usuário é gerente ao carregar a página
async function verificarPermissao() {
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = 'login.html';
            return false;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok' || data.usuario.cargo !== 'gerente') {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = 'index.html';
            return false;
        }

        return true;
    } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        alert('Erro ao verificar permissões');
        window.location.href = 'index.html';
        return false;
    }
}

async function carregarProdutos() {
    try {
        const response = await fetch('/api/produtos', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao carregar produtos');
        }

        const produtos = await response.json();
        const tbody = document.getElementById('produtosTableBody');

        if (produtos.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #666;">Nenhum produto encontrado</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        produtos.forEach(produto => {
            const tr = document.createElement('tr');
            tr.style.borderBottom = '1px solid #eee';

            const statusBadge = produto.ativo 
                ? '<span style="background: #27ae60; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Ativo</span>'
                : '<span style="background: #e74c3c; color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.85rem;">Inativo</span>';

            const descricao = produto.descricao 
                ? (produto.descricao.length > 50 ? produto.descricao.substring(0, 50) + '...' : produto.descricao)
                : 'Sem descrição';

            tr.innerHTML = `
                <td style="padding: 1rem;">${produto.id}</td>
                <td style="padding: 1rem;">${produto.nome}</td>
                <td style="padding: 1rem;">${descricao}</td>
                <td style="padding: 1rem; text-align: center; font-weight: bold; color: #27ae60;">R$ ${parseFloat(produto.preco).toFixed(2)}</td>
                <td style="padding: 1rem; text-align: center;">${statusBadge}</td>
                <td style="padding: 1rem; text-align: center;">
                    <button onclick="editarProduto(${produto.id})" class="btn" style="background: #f39c12; padding: 0.5rem 1rem; margin-right: 0.5rem;">✏️ Editar</button>
                    <button onclick="deletarProduto(${produto.id})" class="btn btn-danger" style="padding: 0.5rem 1rem;">🗑️ Deletar</button>
                </td>
            `;

            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        mostrarErro('Erro ao carregar produtos');
    }
}

async function editarProduto(id) {
    try {
        const response = await fetch(`/api/produtos/${id}`, {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao buscar produto');
        }

        const produto = await response.json();

        editandoId = id;
        document.getElementById('formTitle').textContent = 'Editar Produto';
        document.getElementById('produtoId').value = id;
        document.getElementById('nome').value = produto.nome;
        document.getElementById('preco').value = parseFloat(produto.preco).toFixed(2);
        document.getElementById('descricao').value = produto.descricao || '';
        document.getElementById('ingredientes').value = produto.ingredientes || '';
        document.getElementById('imagem_url').value = produto.imagem_url || '';
        document.getElementById('ativo').value = produto.ativo ? 'true' : 'false';

        // Scroll para o formulário
        document.getElementById('produtoForm').scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Erro ao editar produto:', error);
        mostrarErro('Erro ao carregar dados do produto');
    }
}

async function deletarProduto(id) {
    if (!confirm('Tem certeza que deseja deletar este produto?')) {
        return;
    }

    try {
        const response = await fetch(`/api/produtos/${id}`, {
            method: 'DELETE',
            credentials: 'include'
        });

        if (!response.ok) {
            throw new Error('Erro ao deletar produto');
        }

        mostrarSucesso('Produto deletado com sucesso!');
        carregarProdutos();
    } catch (error) {
        console.error('Erro ao deletar produto:', error);
        mostrarErro('Erro ao deletar produto');
    }
}

function cancelarEdicao() {
    editandoId = null;
    document.getElementById('formTitle').textContent = 'Adicionar Novo Produto';
    document.getElementById('produtoForm').reset();
    document.getElementById('produtoId').value = '';
}

function mostrarErro(mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    successMsg.classList.add('hidden');
    errorMsg.textContent = '✗ ' + mensagem;
    errorMsg.classList.remove('hidden');
    
    setTimeout(() => errorMsg.classList.add('hidden'), 5000);
}

function mostrarSucesso(mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.textContent = '✓ ' + mensagem;
    successMsg.classList.remove('hidden');
    
    setTimeout(() => successMsg.classList.add('hidden'), 5000);
}

// Manipular envio do formulário
document.getElementById('produtoForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const preco = parseFloat(document.getElementById('preco').value);
    const descricao = document.getElementById('descricao').value.trim();
    const ingredientes = document.getElementById('ingredientes').value.trim();
    const imagem_url = document.getElementById('imagem_url').value.trim();
    const ativo = document.getElementById('ativo').value === 'true';

    if (!nome) {
        mostrarErro('Nome é obrigatório');
        return;
    }

    if (isNaN(preco) || preco < 0) {
        mostrarErro('Preço deve ser um valor válido');
        return;
    }

    const dados = {
        nome,
        preco,
        descricao: descricao || null,
        ingredientes: ingredientes || null,
        imagem_url: imagem_url || null,
        ativo
    };

    try {
        let response;
        
        if (editandoId) {
            // Atualizar produto existente
            response = await fetch(`/api/produtos/${editandoId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(dados)
            });
        } else {
            // Criar novo produto
            response = await fetch('/api/produtos', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(dados)
            });
        }

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao salvar produto');
        }

        mostrarSucesso(editandoId ? 'Produto atualizado com sucesso!' : 'Produto criado com sucesso!');
        cancelarEdicao();
        carregarProdutos();
    } catch (error) {
        console.error('Erro ao salvar produto:', error);
        mostrarErro(error.message || 'Erro ao salvar produto');
    }
});

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarProdutos();
        }
    });
} else {
    (async () => {
        const temPermissao = await verificarPermissao();
        if (temPermissao) {
            carregarProdutos();
        }
    })();
}
