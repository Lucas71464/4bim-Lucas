// pagamento.js

let totalPedido = 0;

function carregarResumoPedido() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    const resumoContainer = document.getElementById('resumoPedido');
    const totalContainer = document.getElementById('totalPedido');
    
    if (carrinho.length === 0) {
        alert('Carrinho vazio! Redirecionando...');
        window.location.href = 'cardapio.html';
        return;
    }
    
    let html = '<ul style="list-style: none; padding: 0; margin: 0;">';
    totalPedido = 0;
    
    carrinho.forEach(item => {
        const subtotal = item.preco * item.quantidade;
        totalPedido += subtotal;
        html += `
            <li style="padding: 0.5rem 0; border-bottom: 1px solid #eee;">
                <div style="display: flex; justify-content: space-between;">
                    <span>${item.quantidade}x ${item.nome}</span>
                    <span>R$ ${subtotal.toFixed(2)}</span>
                </div>
            </li>
        `;
    });
    
    html += '</ul>';
    resumoContainer.innerHTML = html;
    totalContainer.textContent = `Total: R$ ${totalPedido.toFixed(2)}`;
}

function mostrarCamposPagamento() {
    const metodo = document.getElementById('metodoPagamento').value;
    
    // Esconder todos primeiro
    document.getElementById('infoPix').style.display = 'none';
    document.getElementById('infoCartao').style.display = 'none';
    document.getElementById('infoDinheiro').style.display = 'none';
    
    // Mostrar campos específicos
    if (metodo === 'dinheiro') {
        document.getElementById('infoDinheiro').style.display = 'block';
    } else if (metodo === 'pix') {
        document.getElementById('infoPix').style.display = 'block';
    } else if (metodo === 'cartao') {
        document.getElementById('infoCartao').style.display = 'block';
    }
    
    calcularTroco();
}

// Renomear a função no HTML
document.getElementById('metodoPagamento').onchange = mostrarCamposPagamento;

function calcularTroco() {
    const trocoPara = parseFloat(document.getElementById('trocoPara').value || 0);
    const trocoCalculado = document.getElementById('trocoCalculado');
    
    if (trocoPara > 0) {
        const troco = trocoPara - totalPedido;
        if (troco < 0) {
            trocoCalculado.innerHTML = `<span style="color: #e74c3c;">⚠️ Valor insuficiente! Faltam R$ ${Math.abs(troco).toFixed(2)}</span>`;
        } else {
            trocoCalculado.innerHTML = `Troco: R$ ${troco.toFixed(2)}`;
        }
    } else {
        trocoCalculado.innerHTML = '';
    }
}

// Validação básica de cartão (apenas para simulação)
function validarCartao() {
    const metodo = document.getElementById('metodoPagamento').value;
    if (metodo !== 'cartao') return true;

    const numero = document.getElementById('numeroCartao').value.replace(/\s/g, '');
    const validade = document.getElementById('validadeCartao').value;
    const cvv = document.getElementById('cvvCartao').value;
    const nome = document.getElementById('nomeCartao').value;

    if (numero.length < 16 || validade.length !== 5 || cvv.length < 3 || nome.length < 3) {
        return false;
    }
    return true;
}

// Atualizar cálculo de troco em tempo real
document.addEventListener('DOMContentLoaded', () => {
    const trocoInput = document.getElementById('trocoPara');
    if (trocoInput) {
        trocoInput.addEventListener('input', calcularTroco);
    }
    
    // Inicializa a exibição correta dos campos de pagamento
    mostrarCamposPagamento();
});

async function confirmarPedido() {
    const metodo = document.getElementById('metodoPagamento').value;
    const opcaoRecebimento = document.getElementById('opcaoRecebimento').value;
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.classList.add('hidden');
    
    if (!opcaoRecebimento) {
        errorMsg.textContent = '✗ Selecione uma opção de recebimento (Entrega ou Retirada)';
        errorMsg.classList.remove('hidden');
        return;
    }

    if (!metodo) {
        errorMsg.textContent = '✗ Selecione um método de pagamento';
        errorMsg.classList.remove('hidden');
        return;
    }

    // Validação de Cartão
    if (metodo === 'cartao' && !validarCartao()) {
        errorMsg.textContent = '✗ Preencha corretamente todos os dados do cartão.';
        errorMsg.classList.remove('hidden');
        return;
    }
    
    let trocoPara = null;
    if (metodo === 'dinheiro') {
        const trocoInput = document.getElementById('trocoPara').value;
        if (trocoInput) {
            trocoPara = parseFloat(trocoInput);
            if (trocoPara < totalPedido) {
                errorMsg.textContent = '✗ Valor do troco é insuficiente para o total do pedido';
                errorMsg.classList.remove('hidden');
                return;
            }
        }
    }

    // Coletar dados do cartão (apenas para simulação e envio)
    let dadosCartao = null;
    if (metodo === 'cartao') {
        dadosCartao = {
            numero: document.getElementById('numeroCartao').value,
            validade: document.getElementById('validadeCartao').value,
            cvv: document.getElementById('cvvCartao').value,
            nome: document.getElementById('nomeCartao').value,
        };
    }
    
    const carrinho = JSON.parse(localStorage.getItem('carrinho') || '[]');
    
    if (carrinho.length === 0) {
        errorMsg.textContent = '✗ Carrinho vazio';
        errorMsg.classList.remove('hidden');
        return;
    }
    
    try {
        // Verificar se está logado
        const meResponse = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });
        
        if (!meResponse.ok) {
            alert('Você precisa estar logado para finalizar o pedido');
            window.location.href = 'login.html';
            return;
        }
        
        const meData = await meResponse.json();
        if (!meData || meData.status !== 'ok') {
            alert('Você precisa estar logado para finalizar o pedido');
            window.location.href = 'login.html';
            return;
        }
        
        // Criar pedido
        const pedidoData = {
            usuario_id: meData.usuario.id,
            valor_total: totalPedido,
            metodo_pagamento: metodo,
            troco_para: trocoPara,
            opcao_recebimento: opcaoRecebimento, // Novo campo
            dados_cartao: dadosCartao, // Novo campo (apenas para simulação)
            itens: carrinho.map(item => ({
                produto_id: item.id,
                quantidade: item.quantidade,
                preco_unit: item.preco
            }))
        };
        
        const response = await fetch('/api/pedidos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify(pedidoData)
        });
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || errorData.error || 'Erro ao criar pedido');
        }
        
        const result = await response.json();
        
        successMsg.textContent = '✓ Pedido confirmado com sucesso!';
        successMsg.classList.remove('hidden');
        
        // Limpar carrinho
        localStorage.removeItem('carrinho');
        
        // Redirecionar após 2 segundos
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 2000);
        
    } catch (error) {
        console.error('Erro ao confirmar pedido:', error);
        errorMsg.textContent = '✗ ' + (error.message || 'Erro ao processar pedido');
        errorMsg.classList.remove('hidden');
    }
}

// Carregar resumo ao inicializar
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarResumoPedido);
} else {
    carregarResumoPedido();
}
