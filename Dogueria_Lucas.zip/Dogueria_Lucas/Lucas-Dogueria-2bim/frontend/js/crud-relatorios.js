// crud-relatorios.js

// Função auxiliar para mostrar mensagens
function mostrarMensagem(tipo, mensagem) {
    const errorMsg = document.getElementById('errorMessage');
    const successMsg = document.getElementById('successMessage');
    
    errorMsg.classList.add('hidden');
    successMsg.classList.add('hidden');

    if (tipo === 'erro') {
        errorMsg.textContent = '✗ ' + mensagem;
        errorMsg.classList.remove('hidden');
    } else if (tipo === 'sucesso') {
        successMsg.textContent = '✓ ' + mensagem;
        successMsg.classList.remove('hidden');
    }
    
    setTimeout(() => {
        errorMsg.classList.add('hidden');
        successMsg.classList.add('hidden');
    }, 5000);
}

// Verificar se usuário é gerente ao carregar a página
async function verificarPermissao() {
    try {
        const response = await fetch('/api/me', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            alert('Você precisa estar logado para acessar esta página');
            window.location.href = '../login.html';
            return false;
        }

        const data = await response.json();
        if (!data || data.status !== 'ok' || data.usuario.cargo !== 'gerente') {
            alert('Acesso negado! Apenas gerentes podem acessar esta página.');
            window.location.href = '../index.html';
            return false;
        }

        return true;
    } catch (error) {
        console.error('Erro ao verificar permissão:', error);
        alert('Erro ao verificar permissões');
        window.location.href = '../index.html';
        return false;
    }
}

// Relatório 1: Vendas por Mês (Impressão)
function abrirRelatorioVendasImpressao() {
    // Abre o endpoint do backend em uma nova janela para visualização e impressão
    window.open('/api/relatorios/vendas-por-mes/imprimir', '_blank');
}

// Relatório 2: Clientes Mais Ativos (Impressão)
function abrirRelatorioClientesImpressao() {
    // Abre o endpoint do backend em uma nova janela para visualização e impressão
    window.open('/api/relatorios/clientes-mais-ativos/imprimir', '_blank');
}

// Relatório 1: Vendas por Mês (Visualização JSON)
document.getElementById('vendasMesBtn').addEventListener('click', async () => {
    const resultadoDiv = document.getElementById('vendasMesResultado');
    resultadoDiv.style.display = 'none';
    resultadoDiv.innerHTML = '<p style="text-align: center;">Carregando...</p>';
    resultadoDiv.style.display = 'block';

    try {
        const response = await fetch('/api/relatorios/vendas-por-mes', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || 'Erro ao buscar relatório de vendas por mês');
        }

        const relatorio = await response.json();

        if (relatorio.dados.length === 0) {
            resultadoDiv.innerHTML = '<p style="text-align: center;">Nenhuma venda encontrada no período.</p>';
            return;
        }

        let tabelaHtml = `
            <h4 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem;">${relatorio.titulo}</h4>
            <p>Gerado em: ${relatorio.data_geracao}</p>
            <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
                <thead>
                    <tr style="background: #f2f2f2;">
                        <th style="padding: 0.5rem; text-align: left;">Mês/Ano</th>
                        <th style="padding: 0.5rem; text-align: center;">Total de Pedidos</th>
                        <th style="padding: 0.5rem; text-align: center;">Total de Vendas (R$)</th>
                    </tr>
                </thead>
                <tbody>
        `;

        let totalGeral = 0;
        let totalPedidosGeral = 0;

        relatorio.dados.forEach(item => {
            totalGeral += parseFloat(item.total_vendas);
            totalPedidosGeral += item.total_pedidos;
            tabelaHtml += `
                <tr>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee;">${item.mes_ano}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">${item.total_pedidos}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">R$ ${item.total_vendas.replace('.', ',')}</td>
                </tr>
            `;
        });

        tabelaHtml += `
                <tr style="font-weight: bold; background: #e6e6e6;">
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee;">TOTAL GERAL</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">${totalPedidosGeral}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">R$ ${totalGeral.toFixed(2).replace('.', ',')}</td>
                </tr>
                </tbody>
            </table>
        `;

        resultadoDiv.innerHTML = tabelaHtml;
        mostrarMensagem('sucesso', 'Relatório de vendas por mês carregado com sucesso!');

    } catch (error) {
        console.error('Erro ao buscar relatório de vendas por mês:', error);
        mostrarMensagem('erro', error.message || 'Erro ao buscar relatório de vendas por mês');
        resultadoDiv.innerHTML = '<p style="text-align: center; color: red;">Erro ao carregar relatório.</p>';
    }
});

// Relatório 2: Clientes Mais Ativos
document.getElementById('clientesAtivosBtn').addEventListener('click', async () => {
    const resultadoDiv = document.getElementById('clientesAtivosResultado');
    resultadoDiv.style.display = 'none';
    resultadoDiv.innerHTML = '<p style="text-align: center;">Carregando...</p>';
    resultadoDiv.style.display = 'block';

    try {
        const response = await fetch('/api/relatorios/clientes-mais-ativos', {
            method: 'GET',
            credentials: 'include'
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || 'Erro ao buscar relatório de clientes mais ativos');
        }

        const relatorio = await response.json();

        if (relatorio.dados.length === 0) {
            resultadoDiv.innerHTML = '<p style="text-align: center;">Nenhum cliente ativo encontrado.</p>';
            return;
        }

        let tabelaHtml = `
            <h4 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem;">${relatorio.titulo}</h4>
            <p>Gerado em: ${relatorio.data_geracao}</p>
            <table style="width: 100%; border-collapse: collapse; margin-top: 1rem;">
                <thead>
                    <tr style="background: #f2f2f2;">
                        <th style="padding: 0.5rem; text-align: left;">#</th>
                        <th style="padding: 0.5rem; text-align: left;">Nome</th>
                        <th style="padding: 0.5rem; text-align: left;">Email</th>
                        <th style="padding: 0.5rem; text-align: center;">Pedidos</th>
                        <th style="padding: 0.5rem; text-align: center;">Total Gasto</th>
                    </tr>
                </thead>
                <tbody>
        `;

        relatorio.dados.forEach((cliente, index) => {
            tabelaHtml += `
                <tr>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee;">${index + 1}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee;">${cliente.nome}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee;">${cliente.email}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">${cliente.total_pedidos}</td>
                    <td style="padding: 0.5rem; border-bottom: 1px solid #eee; text-align: center;">R$ ${cliente.valor_total_gasto.replace('.', ',')}</td>
                </tr>
            `;
        });

        tabelaHtml += `
                </tbody>
            </table>
        `;

        resultadoDiv.innerHTML = tabelaHtml;
        mostrarMensagem('sucesso', 'Relatório de clientes mais ativos carregado com sucesso!');

    } catch (error) {
        console.error('Erro ao buscar relatório de clientes mais ativos:', error);
        mostrarMensagem('erro', error.message || 'Erro ao buscar relatório de clientes mais ativos');
        resultadoDiv.innerHTML = '<p style="text-align: center; color: red;">Erro ao carregar relatório.</p>';
    }
});

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', verificarPermissao);
} else {
    verificarPermissao();
}
