// pedidos-cliente.js

// Função auxiliar para formatar preço
function formatarPreco(preco) {
    return parseFloat(preco).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Função auxiliar para formatar data
function formatarData(data) {
    return new Date(data).toLocaleString('pt-BR', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Função auxiliar para obter o nome do status
function getStatusNome(status) {
    const statusMap = {
        'pendente': 'Pendente',
        'preparacao': 'Em Preparação',
        'transporte': 'Em Transporte',
        'entregue': 'Entregue',
        'cancelado': 'Cancelado'
    };
    return statusMap[status] || status;
}

// Função auxiliar para obter a cor do status
function getStatusCor(status) {
    const statusCor = {
        'pendente': '#f39c12', // Laranja
        'preparacao': '#3498db', // Azul
        'transporte': '#2ecc71', // Verde
        'entregue': '#27ae60', // Verde Escuro
        'cancelado': '#e74c3c' // Vermelho
    };
    return statusCor[status] || '#95a5a6'; // Cinza
}

// Função para carregar e exibir os pedidos do usuário logado
async function carregarPedidos() {
    const pedidosList = document.getElementById('pedidosList');
    pedidosList.innerHTML = '<p style="text-align: center; color: #666;">Carregando pedidos...</p>';

    try {
        // 1. Obter informações do usuário logado
        const userResponse = await fetch('/api/me', { method: 'GET', credentials: 'include' });
        if (userResponse.status === 401) {
            alert('Você precisa estar logado para ver seus pedidos.');
            window.location.href = 'login.html';
            return;
        }
        const userData = await userResponse.json();
        const usuarioId = userData.usuario.id;

        // 2. Obter pedidos do usuário
        const pedidosResponse = await fetch(`/api/pedidos/usuario/${usuarioId}`, {
            method: 'GET',
            credentials: 'include'
        });

        if (!pedidosResponse.ok) {
            throw new Error('Erro ao buscar pedidos');
        }

        const pedidos = await pedidosResponse.json();

        if (pedidos.length === 0) {
            pedidosList.innerHTML = '<p style="text-align: center; color: #666;">Você ainda não fez nenhum pedido.</p>';
            return;
        }

        pedidosList.innerHTML = ''; // Limpa o "Carregando"

        for (const pedido of pedidos) {
            // 3. Obter detalhes (itens) de cada pedido
            const detalhesResponse = await fetch(`/api/pedidos/${pedido.id}`, {
                method: 'GET',
                credentials: 'include'
            });

            if (!detalhesResponse.ok) {
                console.error(`Erro ao carregar detalhes do pedido ${pedido.id}`);
                continue;
            }

            const detalhes = await detalhesResponse.json();

            const statusNome = getStatusNome(pedido.status);
            const statusCor = getStatusCor(pedido.status);

            const pedidoCard = document.createElement('div');
            pedidoCard.style.cssText = `
                background: white;
                padding: 1.5rem;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                border-left: 5px solid ${statusCor};
            `;

            let itensHtml = detalhes.itens.map(item => `
                <li>${item.quantidade}x ${item.produto_nome} (${formatarPreco(item.preco_unit)})</li>
            `).join('');

            pedidoCard.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; padding-bottom: 0.5rem; margin-bottom: 1rem;">
                    <h3 style="margin: 0;">Pedido #${pedido.id}</h3>
                    <span style="background: ${statusCor}; color: white; padding: 0.25rem 0.75rem; border-radius: 4px; font-weight: bold;">${statusNome}</span>
                </div>
                
                <p><strong>Data:</strong> ${formatarData(pedido.criado_em)}</p>
                <p><strong>Total:</strong> <span style="font-weight: bold; color: #27ae60;">${formatarPreco(pedido.valor_total)}</span></p>
                <p><strong>Pagamento:</strong> ${pedido.metodo_pagamento}</p>
                ${pedido.metodo_pagamento === 'dinheiro' && pedido.troco_para ? `<p><strong>Troco para:</strong> ${formatarPreco(pedido.troco_para)}</p>` : ''}
                
                <h4 style="margin-top: 1rem; border-top: 1px solid #eee; padding-top: 0.5rem;">Itens:</h4>
                <ul style="list-style: none; padding: 0; margin: 0;">
                    ${itensHtml}
                </ul>
            `;

            pedidosList.appendChild(pedidoCard);
        }

    } catch (error) {
        console.error('Erro fatal ao carregar pedidos:', error);
        pedidosList.innerHTML = `<p style="text-align: center; color: #e74c3c;">Erro ao carregar pedidos: ${error.message}</p>`;
    }
}

// Inicializar ao carregar a página
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', carregarPedidos);
} else {
    carregarPedidos();
}
