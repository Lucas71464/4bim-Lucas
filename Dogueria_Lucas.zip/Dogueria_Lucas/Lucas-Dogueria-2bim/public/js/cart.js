/**
 * Cart.js - Gerenciador de carrinho para Dogueria
 * Funções para adicionar, remover e gerenciar itens do carrinho
 */

const CART_KEY = 'dogueria_carrinho';

/**
 * Obter carrinho do localStorage
 * @returns {Array} Array de itens no carrinho
 */
function getCart() {
  const carrinhoJSON = localStorage.getItem(CART_KEY);
  return carrinhoJSON ? JSON.parse(carrinhoJSON) : [];
}

/**
 * Salvar carrinho no localStorage
 * @param {Array} carrinho - Array de itens do carrinho
 */
function saveCart(carrinho) {
  localStorage.setItem(CART_KEY, JSON.stringify(carrinho));
  console.log('💾 Carrinho salvo:', carrinho);
  dispatchCartEvent('cartUpdated', carrinho);
}

/**
 * Adicionar item ao carrinho
 * @param {Object} produto - Objeto com id, nome, preco, etc
 * @param {Number} quantidade - Quantidade a adicionar
 */
function addToCart(produto, quantidade = 1) {
  if (!produto || !produto.id) {
    console.error('❌ Produto inválido');
    return false;
  }

  if (quantidade <= 0) {
    console.error('❌ Quantidade deve ser maior que 0');
    return false;
  }

  const carrinho = getCart();

  // Verificar se produto já existe no carrinho
  const itemExistente = carrinho.find(item => item.id === produto.id);

  if (itemExistente) {
    // Aumentar quantidade
    itemExistente.quantidade += quantidade;
    console.log(`📦 Quantidade do item ${produto.nome} aumentada para ${itemExistente.quantidade}`);
  } else {
    // Adicionar novo item
    carrinho.push({
      id: produto.id,
      nome: produto.nome,
      preco: produto.preco,
      quantidade: quantidade,
      descricao: produto.descricao || '',
      imagem_url: produto.imagem_url || ''
    });
    console.log(`➕ Novo item adicionado ao carrinho: ${produto.nome}`);
  }

  saveCart(carrinho);
  return true;
}

/**
 * Remover item do carrinho
 * @param {Number} produtoId - ID do produto a remover
 */
function removeFromCart(produtoId) {
  let carrinho = getCart();
  const itemIndex = carrinho.findIndex(item => item.id === produtoId);

  if (itemIndex === -1) {
    console.error('❌ Item não encontrado no carrinho');
    return false;
  }

  const itemRemovido = carrinho[itemIndex];
  carrinho.splice(itemIndex, 1);
  console.log(`🗑️ Item removido do carrinho: ${itemRemovido.nome}`);

  saveCart(carrinho);
  return true;
}

/**
 * Atualizar quantidade de um item
 * @param {Number} produtoId - ID do produto
 * @param {Number} novaQuantidade - Nova quantidade
 */
function updateCartItemQuantity(produtoId, novaQuantidade) {
  if (novaQuantidade <= 0) {
    return removeFromCart(produtoId);
  }

  const carrinho = getCart();
  const item = carrinho.find(item => item.id === produtoId);

  if (!item) {
    console.error('❌ Item não encontrado no carrinho');
    return false;
  }

  item.quantidade = novaQuantidade;
  console.log(`🔄 Quantidade do item ${item.nome} atualizada para ${novaQuantidade}`);

  saveCart(carrinho);
  return true;
}

/**
 * Obter total do carrinho
 * @returns {Number} Total em reais
 */
function getTotal() {
  const carrinho = getCart();
  const total = carrinho.reduce((soma, item) => soma + (item.preco * item.quantidade), 0);
  return parseFloat(total.toFixed(2));
}

/**
 * Obter quantidade total de itens
 * @returns {Number} Quantidade total de itens
 */
function getCartItemCount() {
  const carrinho = getCart();
  return carrinho.reduce((soma, item) => soma + item.quantidade, 0);
}

/**
 * Limpar carrinho
 */
function clearCart() {
  localStorage.removeItem(CART_KEY);
  console.log('🗑️ Carrinho limpo');
  dispatchCartEvent('cartCleared', []);
}

/**
 * Verificar se carrinho está vazio
 * @returns {Boolean}
 */
function isCartEmpty() {
  return getCart().length === 0;
}

/**
 * Enviar carrinho para o servidor (criar pedido)
 * @param {String} metodo_pagamento - 'pix', 'cartao' ou 'dinheiro'
 * @param {Number} troco_para - Valor para troco (opcional, apenas para dinheiro)
 * @returns {Promise<Object>} Resposta do servidor
 */
async function checkoutCart(metodo_pagamento = 'pix', troco_para = null) {
  try {
    const carrinho = getCart();

    if (carrinho.length === 0) {
      throw new Error('Carrinho vazio');
    }

    // Validar método de pagamento
    if (!['pix', 'cartao', 'dinheiro'].includes(metodo_pagamento)) {
      throw new Error('Método de pagamento inválido');
    }

    // Preparar payload
    const payload = {
      itens: carrinho.map(item => ({
        produto_id: item.id,
        quantidade: item.quantidade,
        preco_unit: item.preco
      })),
      valor_total: getTotal(),
      metodo_pagamento: metodo_pagamento,
      troco_para: troco_para
    };

    console.log('📤 Enviando pedido:', payload);

    // Fazer requisição para criar pedido
    const response = await fetch('/api/pedidos', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.mensagem || 'Erro ao criar pedido');
    }

    const resultado = await response.json();
    console.log('✅ Pedido criado com sucesso:', resultado.pedido);

    // Limpar carrinho após sucesso
    clearCart();

    return resultado;
  } catch (error) {
    console.error('❌ Erro ao fazer checkout:', error);
    throw error;
  }
}

/**
 * Disparar evento customizado
 * @param {String} eventName - Nome do evento
 * @param {*} detail - Detalhes do evento
 */
function dispatchCartEvent(eventName, detail) {
  const event = new CustomEvent(eventName, {
    detail: detail,
    bubbles: true,
    cancelable: true
  });
  document.dispatchEvent(event);
}

/**
 * Adicionar listener para mudanças no carrinho
 * @param {Function} callback - Função chamada quando carrinho muda
 */
function onCartUpdate(callback) {
  document.addEventListener('cartUpdated', (e) => {
    callback(e.detail);
  });
}

/**
 * Adicionar listener para limpeza do carrinho
 * @param {Function} callback - Função chamada quando carrinho é limpo
 */
function onCartClear(callback) {
  document.addEventListener('cartCleared', (e) => {
    callback(e.detail);
  });
}

// Exportar funções (compatível com CommonJS e ES Modules)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    getCart,
    saveCart,
    addToCart,
    removeFromCart,
    updateCartItemQuantity,
    getTotal,
    getCartItemCount,
    clearCart,
    isCartEmpty,
    checkoutCart,
    onCartUpdate,
    onCartClear
  };
}
